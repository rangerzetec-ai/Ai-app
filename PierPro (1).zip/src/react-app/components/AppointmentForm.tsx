import { useState, useEffect } from "react";
import { Save, X, Calendar } from "lucide-react";
import { CreateAppointment, UpdateAppointment, Appointment, Lead, CategorizedPhoto } from "../../shared/types";
import AppointmentMediaUpload from "./AppointmentMediaUpload";
import CategorizedPhotoUpload from "./CategorizedPhotoUpload";
import AddressAutocomplete from "./AddressAutocomplete";
import { FormSection, FormField, StandardInput, StandardTextarea, StandardSelect } from "./shared/FormField";
import SalesPersonSection from "./shared/SalesPersonSection";
import FoundationInfoSection from "./shared/FoundationInfoSection";

interface AppointmentFormProps {
  appointment?: Appointment;
  lead?: Lead;
  leadId?: number;
  onSubmit: (data: CreateAppointment | UpdateAppointment) => Promise<void>;
  onCancel: () => void;
  isEditing: boolean;
  preSelectedDate?: string;
}

export default function AppointmentForm({ 
  appointment, 
  lead, 
  leadId, 
  onSubmit, 
  onCancel, 
  isEditing,
  preSelectedDate 
}: AppointmentFormProps) {
  const [formData, setFormData] = useState({
    lead_id: appointment?.lead_id || leadId || 0,
    appointment_date: appointment?.appointment_date 
      ? new Date(appointment.appointment_date).toISOString().slice(0, 16)
      : preSelectedDate || "",
    appointment_type: appointment?.appointment_type || "consultation",
    status: appointment?.status || "scheduled",
    notes: appointment?.notes || "",
    location_address: appointment?.location_address || "",
    duration_minutes: appointment?.duration_minutes || 60,
    site_photos: appointment?.site_photos || "",
    improvement_sketch_url: appointment?.improvement_sketch_url || "",
    improvement_sketch_filename: appointment?.improvement_sketch_filename || "",
    technician_notes: appointment?.technician_notes || "",
    assigned_sales_person_id: appointment?.assigned_sales_person_id?.toString() || "",
    foundation_type: appointment?.foundation_type || "",
    pier_type: appointment?.pier_type || "",
  });

  const [categorizedPhotos, setCategorizedPhotos] = useState<CategorizedPhoto[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // Fetch existing categorized photos if editing
    if (isEditing && appointment?.id) {
      const fetchCategorizedPhotos = async () => {
        try {
          const response = await fetch(`/api/appointments/${appointment.id}/photos`);
          if (response.ok) {
            const photos = await response.json();
            setCategorizedPhotos(photos);
          }
        } catch (error) {
          console.error("Failed to fetch categorized photos:", error);
        }
      };
      fetchCategorizedPhotos();
    }
  }, [isEditing, appointment?.id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ 
      ...prev, 
      [name]: type === "number" ? parseInt(value) || 0 : value 
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.appointment_date) {
      newErrors.appointment_date = "Appointment date is required";
    } else {
      const appointmentDate = new Date(formData.appointment_date);
      const now = new Date();
      if (appointmentDate < now) {
        newErrors.appointment_date = "Appointment date cannot be in the past";
      }
    }
    
    if (!formData.location_address) {
      newErrors.location_address = "Property address is required";
    }
    
    if (formData.duration_minutes <= 0) {
      newErrors.duration_minutes = "Duration must be greater than 0";
    }
    
    if (formData.foundation_type === "pier_and_beam" && !formData.pier_type) {
      newErrors.pier_type = "Please select the pier type for pier and beam foundations";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setSaving(true);
    try {
      // Convert local datetime to ISO string
      const submitData = {
        ...formData,
        appointment_date: new Date(formData.appointment_date).toISOString(),
        // Filter out empty strings for optional fields
        notes: formData.notes || undefined,
        location_address: formData.location_address || undefined,
        assigned_sales_person_id: formData.assigned_sales_person_id ? parseInt(formData.assigned_sales_person_id.toString()) : undefined,
        foundation_type: (formData.foundation_type as "slab" | "pier_and_beam") || undefined,
        pier_type: (formData.pier_type as "poured" | "blocks" | "posts") || undefined,
      };
      
      await onSubmit(submitData);
    } catch (error) {
      console.error("Failed to save appointment:", error);
      setErrors({ general: "Failed to save appointment. Please try again." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl p-6">
      <form onSubmit={handleSubmit} className="space-y-8">
        {errors.general && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">{errors.general}</p>
          </div>
        )}

        {/* Lead Information (if provided) */}
        {lead && (
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-purple-600" />
              <span className="font-medium text-purple-900">
                Appointment for: {lead.first_name} {lead.last_name}
              </span>
            </div>
            {lead.email && (
              <p className="text-purple-700 text-sm mt-1">{lead.email}</p>
            )}
          </div>
        )}

        <FormSection title="Appointment Details" icon={<Calendar className="w-5 h-5 text-indigo-600" />}>
          {/* Date and Duration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Appointment Date & Time" required error={errors.appointment_date}>
              <StandardInput
                name="appointment_date"
                type="datetime-local"
                value={formData.appointment_date}
                onChange={handleChange}
                error={errors.appointment_date}
              />
            </FormField>

            <FormField label="Duration (minutes)" error={errors.duration_minutes}>
              <StandardInput
                name="duration_minutes"
                type="number"
                value={formData.duration_minutes.toString()}
                onChange={handleChange}
                min="15"
                step="15"
                error={errors.duration_minutes}
              />
            </FormField>
          </div>

          {/* Type, Status, and Sales Person */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FormField label="Appointment Type" error={errors.appointment_type}>
              <StandardSelect
                name="appointment_type"
                value={formData.appointment_type}
                onChange={handleChange}
                error={errors.appointment_type}
              >
                <option value="consultation">Consultation</option>
                <option value="estimate">Estimate</option>
                <option value="inspection">Inspection</option>
                <option value="follow_up">Follow Up</option>
              </StandardSelect>
            </FormField>

            <FormField label="Status" error={errors.status}>
              <StandardSelect
                name="status"
                value={formData.status}
                onChange={handleChange}
                error={errors.status}
              >
                <option value="scheduled">Scheduled</option>
                <option value="confirmed">Confirmed</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
                <option value="no_show">No Show</option>
              </StandardSelect>
            </FormField>

            <SalesPersonSection
              value={formData.assigned_sales_person_id}
              onChange={handleChange}
              error={errors.assigned_sales_person_id}
              label="Sales Person"
            />
          </div>

          {/* Property Address */}
          <FormField label="Property Address" required error={errors.location_address}>
            <AddressAutocomplete
              value={formData.location_address}
              onChange={(address) => setFormData(prev => ({ ...prev, location_address: address }))}
              placeholder="Start typing property address..."
            />
          </FormField>

          {/* Foundation Information */}
          <FoundationInfoSection
            data={formData}
            onChange={handleChange}
            errors={errors}
          />

          {/* Notes */}
          <FormField label="Notes" error={errors.notes}>
            <StandardTextarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={4}
              placeholder="Add any additional notes about this appointment..."
              error={errors.notes}
            />
          </FormField>

          {/* Technician Notes */}
          <FormField label="Technician Notes" error={errors.technician_notes}>
            <StandardTextarea
              name="technician_notes"
              value={formData.technician_notes}
              onChange={handleChange}
              rows={3}
              placeholder="Field notes, site conditions, special requirements..."
              error={errors.technician_notes}
            />
          </FormField>
        </FormSection>

        {/* Media Upload - only show for existing appointments */}
        {isEditing && appointment && (
          <FormSection title="Documentation">
            <FormField label="Photo Documentation">
              <CategorizedPhotoUpload
                appointmentId={appointment.id}
                existingPhotos={categorizedPhotos}
                onPhotosChanged={setCategorizedPhotos}
              />
            </FormField>
            
            {/* Legacy sketch upload for backward compatibility */}
            <div className="pt-6 border-t border-slate-200">
              <FormField label="Improvement Sketch (Legacy)">
                <AppointmentMediaUpload
                  appointmentId={appointment.id}
                  existingPhotos={appointment.site_photos ? JSON.parse(appointment.site_photos) : []}
                  existingSketch={appointment.improvement_sketch_url ? {
                    url: appointment.improvement_sketch_url,
                    filename: appointment.improvement_sketch_filename || "sketch.png"
                  } : null}
                  onPhotoUploaded={(url) => {
                    const photos = formData.site_photos ? JSON.parse(formData.site_photos) : [];
                    photos.push(url);
                    setFormData(prev => ({ ...prev, site_photos: JSON.stringify(photos) }));
                  }}
                  onSketchUploaded={(url, filename) => {
                    setFormData(prev => ({ 
                      ...prev, 
                      improvement_sketch_url: url,
                      improvement_sketch_filename: filename
                    }));
                  }}
                />
              </FormField>
            </div>
          </FormSection>
        )}

        {/* Form Actions */}
        <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-200">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center px-4 py-2 border border-slate-300 text-slate-700 bg-white rounded-lg hover:bg-slate-50 transition-colors"
          >
            <X className="w-4 h-4 mr-2" />
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Saving..." : isEditing ? "Update Appointment" : "Schedule Appointment"}
          </button>
        </div>
      </form>
    </div>
  );
}
