
UPDATE password_users 
SET password_hash = '$2a$10$YourActualHashWillGoHere', 
    updated_at = CURRENT_TIMESTAMP 
WHERE email = 'RangerZetec@gmail.com';

UPDATE user_roles 
SET role = 'admin', 
    updated_at = CURRENT_TIMESTAMP 
WHERE user_id = (
  SELECT 'password_user_' || id 
  FROM password_users 
  WHERE email = 'RangerZetec@gmail.com'
);
