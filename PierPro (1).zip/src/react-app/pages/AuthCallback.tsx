import { useAuth } from "../hooks/useAuth";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Building2 } from "lucide-react";

export default function AuthCallback() {
  const { exchangeCodeForSessionToken, user } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(true);

  useEffect(() => {
    const processAuth = async () => {
      try {
        setIsProcessing(true);
        setError(null);
        
        // Exchange the code for session token
        await exchangeCodeForSessionToken();
        
        // Redirect to dashboard on success
        navigate("/dashboard", { replace: true });
      } catch (error) {
        console.error("Authentication failed:", error);
        setError("Authentication failed. Please try again.");
        setIsProcessing(false);
        
        // Redirect to login after error
        setTimeout(() => {
          navigate("/login", { replace: true });
        }, 3000);
      }
    };

    // Only process if we don't already have a user
    if (!user) {
      processAuth();
    } else {
      // User is already authenticated, redirect to dashboard
      navigate("/dashboard", { replace: true });
    }
  }, [exchangeCodeForSessionToken, navigate, user]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-md w-full mx-auto">
        <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-3xl p-8 shadow-xl shadow-blue-500/10 text-center">
          {/* Logo */}
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Building2 className="w-8 h-8 text-white" />
          </div>

          {isProcessing && !error && (
            <>
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Signing you in...</h2>
              <p className="text-slate-600">Please wait while we complete your authentication</p>
            </>
          )}

          {error && (
            <>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-red-600 text-xl">✕</span>
              </div>
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Authentication Error</h2>
              <p className="text-slate-600 mb-4">{error}</p>
              <p className="text-sm text-slate-500">Redirecting you back to login...</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
