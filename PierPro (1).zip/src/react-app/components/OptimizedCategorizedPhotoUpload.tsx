import React, { useState, useCallback, memo, useMemo } from "react";
import { Upload, X, Camera, AlertCircle, ImageIcon, Loader2 } from "lucide-react";
import { useImageOptimization } from "../hooks/useImageOptimization";
import { useDebounce } from "../hooks/useDebounce";
import { CategorizedPhoto } from "@/shared/types";

interface OptimizedCategorizedPhotoUploadProps {
  appointmentId: string;
  existingPhotos: CategorizedPhoto[];
  onPhotosChanged: (photos: CategorizedPhoto[]) => void;
  maxPhotos?: number;
  maxFileSize?: number; // in MB
}

const PHOTO_CATEGORIES = [
  { value: "structural_damage", label: "Structural Damage", color: "red", icon: "🏗️" },
  { value: "foundation_issues", label: "Foundation Issues", color: "orange", icon: "🏠" },
  { value: "site_conditions", label: "Site Conditions", color: "blue", icon: "🌍" },
  { value: "access_points", label: "Access Points", color: "green", icon: "🚪" },
  { value: "before_work", label: "Before Work", color: "purple", icon: "📸" },
  { value: "psych_photos", label: "Psychology Photos", color: "pink", icon: "✨" },
  { value: "other", label: "Other", color: "gray", icon: "📋" },
] as const;

const OptimizedPhotoCard = memo(({ 
  photo, 
  onRemove, 
  onUpdateDescription 
}: { 
  photo: CategorizedPhoto; 
  onRemove: (id: string) => void;
  onUpdateDescription: (id: string, description: string) => void;
}) => {
  const [description, setDescription] = useState(photo.description || "");
  const [isUpdating, setIsUpdating] = useState(false);
  
  const debouncedDescription = useDebounce(description, 500);

  React.useEffect(() => {
    if (debouncedDescription !== photo.description && debouncedDescription.trim() && photo.id != null) {
      setIsUpdating(true);
      onUpdateDescription(String(photo.id), debouncedDescription);
      setTimeout(() => setIsUpdating(false), 300);
    }
  }, [debouncedDescription, photo.description, photo.id, onUpdateDescription]);

  const categoryInfo = PHOTO_CATEGORIES.find(cat => cat.value === photo.type);

  return (
    <div className="relative group bg-white rounded-lg shadow-md overflow-hidden">
      <div className="aspect-video relative">
        <img
          src={`/api/files/${photo.url}`}
          alt={photo.description || "Photo"}
          className="w-full h-full object-cover"
          loading="lazy"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="150"><rect width="200" height="150" fill="%23f3f4f6"/><text x="100" y="75" text-anchor="middle" fill="%236b7280">Image not found</text></svg>';
          }}
        />
        <div className={`absolute top-2 left-2 px-2 py-1 rounded text-xs font-medium bg-${categoryInfo?.color}-100 text-${categoryInfo?.color}-800`}>
          {categoryInfo?.icon} {categoryInfo?.label}
        </div>
        <button
          onClick={() => photo.id != null && onRemove(String(photo.id))}
          className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
        >
          <X className="w-3 h-3" />
        </button>
      </div>
      <div className="p-3">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Add description..."
            className="flex-1 text-sm border border-slate-200 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {isUpdating && (
            <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />
          )}
        </div>
        <div className="text-xs text-slate-500 mt-1">
          Recent
        </div>
      </div>
    </div>
  );
});

OptimizedPhotoCard.displayName = 'OptimizedPhotoCard';

export default memo(function OptimizedCategorizedPhotoUpload({
  appointmentId,
  existingPhotos,
  onPhotosChanged,
  maxPhotos = 50,
  maxFileSize = 10 // 10MB
}: OptimizedCategorizedPhotoUploadProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("structural_damage");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  
  const { optimizeImage, isOptimizing } = useImageOptimization();

  const groupedPhotos = useMemo(() => {
    return PHOTO_CATEGORIES.reduce((acc, category) => {
      acc[category.value] = existingPhotos.filter(photo => photo.type === category.value);
      return acc;
    }, {} as Record<string, CategorizedPhoto[]>);
  }, [existingPhotos]);

  const totalPhotos = existingPhotos.length;
  const canUploadMore = totalPhotos < maxPhotos;

  const handleFileSelect = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    const remainingSlots = maxPhotos - totalPhotos;
    const filesToProcess = files.slice(0, remainingSlots);

    if (files.length > remainingSlots) {
      setError(`Only ${remainingSlots} more photos can be uploaded (maximum ${maxPhotos})`);
      setTimeout(() => setError(null), 5000);
    }

    setUploading(true);
    setError(null);
    setUploadProgress(0);

    try {
      for (let i = 0; i < filesToProcess.length; i++) {
        const file = filesToProcess[i];

        // Validate file size
        if (file.size > maxFileSize * 1024 * 1024) {
          throw new Error(`File ${file.name} exceeds ${maxFileSize}MB limit`);
        }

        // Validate file type
        if (!file.type.startsWith('image/')) {
          throw new Error(`File ${file.name} is not an image`);
        }

        // Optimize image
        const optimizedFile = await optimizeImage(file, {
          maxWidth: 1920,
          maxHeight: 1080,
          quality: 0.8,
          format: 'jpeg'
        });

        // Upload to server
        const formData = new FormData();
        formData.append("photo", optimizedFile);
        formData.append("type", selectedCategory);
        formData.append("description", "");

        const response = await fetch(`/api/appointments/${appointmentId}/photos`, {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ error: 'Upload failed' }));
          throw new Error(errorData.error || 'Upload failed');
        }

        const newPhoto = await response.json();
        onPhotosChanged([...existingPhotos, newPhoto]);

        setUploadProgress(((i + 1) / filesToProcess.length) * 100);
      }
    } catch (err) {
      console.error("Upload error:", err);
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
      setUploadProgress(0);
      // Reset file input
      event.target.value = '';
    }
  }, [appointmentId, selectedCategory, existingPhotos, onPhotosChanged, optimizeImage, maxPhotos, maxFileSize, totalPhotos]);

  const handleRemovePhoto = useCallback(async (photoId: string) => {
    try {
      const response = await fetch(`/api/appointments/${appointmentId}/photos/${photoId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        onPhotosChanged(existingPhotos.filter(photo => String(photo.id) !== photoId));
      } else {
        throw new Error('Failed to delete photo');
      }
    } catch (err) {
      console.error("Delete error:", err);
      setError("Failed to delete photo");
      setTimeout(() => setError(null), 3000);
    }
  }, [appointmentId, existingPhotos, onPhotosChanged]);

  const handleUpdateDescription = useCallback(async (photoId: string, description: string) => {
    try {
      const response = await fetch(`/api/appointments/${appointmentId}/photos/${photoId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ description }),
      });

      if (response.ok) {
        const updatedPhoto = await response.json();
        onPhotosChanged(existingPhotos.map(photo => 
          String(photo.id) === photoId ? updatedPhoto : photo
        ));
      }
    } catch (err) {
      console.error("Update error:", err);
      setError("Failed to update description");
      setTimeout(() => setError(null), 3000);
    }
  }, [appointmentId, existingPhotos, onPhotosChanged]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-900 flex items-center">
          <Camera className="w-5 h-5 mr-2" />
          Photo Documentation ({totalPhotos}/{maxPhotos})
        </h3>
        {totalPhotos > 20 && (
          <div className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded">
            ⚡ Large collection - optimized loading
          </div>
        )}
      </div>

      {/* Upload Section */}
      <div className="bg-slate-50 rounded-lg p-4">
        <div className="space-y-4">
          {/* Category Selection */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Photo Category
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {PHOTO_CATEGORIES.map((category) => (
                <button
                  key={category.value}
                  onClick={() => setSelectedCategory(category.value)}
                  className={`p-2 text-xs rounded-lg border transition-all ${
                    selectedCategory === category.value
                      ? `bg-${category.color}-100 border-${category.color}-300 text-${category.color}-800`
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <div className="font-medium">{category.icon}</div>
                  <div>{category.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Upload Button */}
          <div className="flex items-center space-x-4">
            <label className={`inline-flex items-center px-4 py-2 rounded-lg transition-colors cursor-pointer ${
              canUploadMore && !uploading
                ? "bg-blue-600 text-white hover:bg-blue-700"
                : "bg-slate-300 text-slate-500 cursor-not-allowed"
            }`}>
              {uploading || isOptimizing ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Upload className="w-4 h-4 mr-2" />
              )}
              {uploading ? "Uploading..." : isOptimizing ? "Optimizing..." : "Upload Photos"}
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileSelect}
                disabled={!canUploadMore || uploading || isOptimizing}
                className="hidden"
              />
            </label>
            
            {uploading && (
              <div className="flex-1 max-w-xs">
                <div className="bg-slate-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
                <div className="text-xs text-slate-600 mt-1">{Math.round(uploadProgress)}%</div>
              </div>
            )}
          </div>

          {!canUploadMore && (
            <div className="text-xs text-orange-600 bg-orange-50 p-2 rounded">
              Maximum photo limit reached ({maxPhotos} photos)
            </div>
          )}
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center">
          <AlertCircle className="w-4 h-4 text-red-500 mr-2 flex-shrink-0" />
          <span className="text-red-700 text-sm">{error}</span>
        </div>
      )}

      {/* Photos by Category */}
      <div className="space-y-6">
        {PHOTO_CATEGORIES.map((category) => {
          const categoryPhotos = groupedPhotos[category.value];
          if (categoryPhotos.length === 0) return null;

          return (
            <div key={category.value}>
              <h4 className="font-medium text-slate-900 mb-3 flex items-center">
                <span className="mr-2">{category.icon}</span>
                {category.label} ({categoryPhotos.length})
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categoryPhotos.map((photo) => (
                  <OptimizedPhotoCard
                    key={photo.id}
                    photo={photo}
                    onRemove={handleRemovePhoto}
                    onUpdateDescription={handleUpdateDescription}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {totalPhotos === 0 && (
        <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-lg">
          <ImageIcon className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600">No photos uploaded yet</p>
          <p className="text-slate-500 text-sm">Select a category and upload photos to document the site</p>
        </div>
      )}
    </div>
  );
});
