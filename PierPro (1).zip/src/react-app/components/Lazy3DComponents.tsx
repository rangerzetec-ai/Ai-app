import { Suspense, lazy, memo } from "react";

// Lazy load all 3D components to prevent esbuild deadlock
export const LazyThreeDViewer = lazy(() => import("./ThreeDViewer"));
export const LazyGenerated3DModel = lazy(() => import("./Generated3DModel"));
export const LazyEnhanced3DViewer = lazy(() => import("./Enhanced3DViewer"));

interface Lazy3DComponentProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

const Lazy3DWrapper = memo(({ children, fallback }: Lazy3DComponentProps) => (
  <Suspense fallback={
    fallback || (
      <div className="flex items-center justify-center h-64 bg-slate-50 rounded-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-slate-600">Loading 3D viewer...</p>
        </div>
      </div>
    )
  }>
    {children}
  </Suspense>
));

Lazy3DWrapper.displayName = 'Lazy3DWrapper';

export default Lazy3DWrapper;
