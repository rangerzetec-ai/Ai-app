import { FormField, StandardInput } from "./FormField";

interface ContactInfoSectionProps {
  data: {
    first_name: string;
    last_name: string;
    email: string;
    phone: string;
  };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  errors: Record<string, string>;
  required?: {
    first_name?: boolean;
    last_name?: boolean;
    email?: boolean;
    phone?: boolean;
  };
}

export default function ContactInfoSection({ 
  data, 
  onChange, 
  errors, 
  required = { first_name: true, last_name: true } 
}: ContactInfoSectionProps) {
  return (
    <>
      {/* Name Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField 
          label="First Name" 
          required={required.first_name} 
          error={errors.first_name}
        >
          <StandardInput
            name="first_name"
            value={data.first_name}
            onChange={onChange}
            placeholder="Enter first name"
            error={errors.first_name}
          />
        </FormField>

        <FormField 
          label="Last Name" 
          required={required.last_name} 
          error={errors.last_name}
        >
          <StandardInput
            name="last_name"
            value={data.last_name}
            onChange={onChange}
            placeholder="Enter last name"
            error={errors.last_name}
          />
        </FormField>
      </div>

      {/* Contact Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField 
          label="Email" 
          required={required.email} 
          error={errors.email}
        >
          <StandardInput
            name="email"
            type="email"
            value={data.email}
            onChange={onChange}
            placeholder="Enter email address"
            error={errors.email}
          />
        </FormField>

        <FormField 
          label="Phone" 
          required={required.phone} 
          error={errors.phone}
        >
          <StandardInput
            name="phone"
            type="tel"
            value={data.phone}
            onChange={onChange}
            placeholder="Enter phone number"
            error={errors.phone}
          />
        </FormField>
      </div>
    </>
  );
}
