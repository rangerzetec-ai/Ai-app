import { useState, useEffect, memo } from "react";
import { BarChart3, TrendingUp, DollarSign, Users } from "lucide-react";
import { ReportMetrics } from "../../shared/types";

interface SimpleReportsModuleProps {
  data?: ReportMetrics;
}

const SimpleReportsModule = memo(function SimpleReportsModule({ data }: SimpleReportsModuleProps) {
  const [metrics, setMetrics] = useState<ReportMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchReportsData = async () => {
      if (data) {
        setMetrics(data);
        setLoading(false);
        return;
      }

      try {
        const response = await fetch("/api/reports/metrics");
        if (response.ok) {
          const reportsData = await response.json();
          setMetrics(reportsData);
        } else {
          setError("Failed to fetch reports data");
        }
      } catch (err) {
        setError("Network error loading reports");
      } finally {
        setLoading(false);
      }
    };

    fetchReportsData();
  }, [data]);

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-20 bg-slate-200 rounded"></div>
            <div className="h-20 bg-slate-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !metrics) {
    return (
      <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
        <div className="text-center text-slate-500">
          <BarChart3 className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p>{error || "No report data available"}</p>
        </div>
      </div>
    );
  }

  const performanceStats = [
    {
      label: "Conversion Rate",
      value: metrics.total_leads > 0 ? ((metrics.converted_leads / metrics.total_leads) * 100).toFixed(1) + "%" : "0%",
      icon: TrendingUp,
      color: "text-green-600"
    },
    {
      label: "Avg Project Value", 
      value: `$${(metrics.average_project_value || 0).toLocaleString()}`,
      icon: DollarSign,
      color: "text-blue-600"
    },
    {
      label: "Active Projects",
      value: metrics.active_projects || 0,
      icon: Users,
      color: "text-purple-600"
    },
    {
      label: "Profit Margin",
      value: `${(metrics.profit_margin || 0).toFixed(1)}%`,
      icon: BarChart3,
      color: "text-orange-600"
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-slate-900">Business Performance</h3>
        <BarChart3 className="w-5 h-5 text-slate-400" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {performanceStats.map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <div key={index} className="text-center p-4 bg-slate-50 rounded-lg">
              <IconComponent className={`w-6 h-6 mx-auto mb-2 ${stat.color}`} />
              <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
              <div className="text-sm text-slate-600">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* Summary Text */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="text-sm text-blue-800">
          <strong>Performance Summary:</strong> 
          {metrics.total_leads > 0 && (
            <span> {metrics.converted_leads} of {metrics.total_leads} leads converted.</span>
          )}
          {metrics.total_revenue > 0 && (
            <span> Total revenue: ${metrics.total_revenue.toLocaleString()}.</span>
          )}
          {metrics.active_projects > 0 && (
            <span> {metrics.active_projects} projects currently active.</span>
          )}
        </div>
      </div>
    </div>
  );
});

export default SimpleReportsModule;
