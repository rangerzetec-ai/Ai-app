// Optimized imports to prevent esbuild deadlock
import { lazy, Suspense } from 'react';

// Lazy load heavy chart components
export const LazyLineChart = lazy(() => 
  import('recharts').then(module => ({ default: module.LineChart }))
);

export const LazyBarChart = lazy(() => 
  import('recharts').then(module => ({ default: module.BarChart }))
);

export const LazyPieChart = lazy(() => 
  import('recharts').then(module => ({ default: module.PieChart }))
);

// Lazy load 3D fiber components
export const LazyCanvas = lazy(() => 
  import('@react-three/fiber').then(module => ({ default: module.Canvas }))
);

// Generic chart wrapper
interface ChartWrapperProps {
  children: React.ReactNode;
  loading?: boolean;
}

export const ChartWrapper = ({ children, loading = false }: ChartWrapperProps) => (
  <Suspense fallback={
    <div className="h-64 bg-slate-50 rounded-lg flex items-center justify-center">
      {loading ? (
        <div className="text-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-sm text-slate-600">Loading chart...</p>
        </div>
      ) : (
        <p className="text-slate-400">Chart unavailable</p>
      )}
    </div>
  }>
    {children}
  </Suspense>
);

export default { LazyLineChart, LazyBarChart, LazyPieChart, LazyCanvas, ChartWrapper };
