
CREATE TABLE password_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  name TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_password_users_email ON password_users(email);

-- Insert the admin user
INSERT INTO password_users (email, password_hash, name, is_active, created_at, updated_at)
VALUES ('RangerZetec@gmail.com', '$2a$10$N9qo8uLOickgx2ZMRZoMye5IFrCdX42j2oS5bRxRlIgJGpT3dC2oG', 'Admin User', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Add the admin user role
INSERT INTO user_roles (user_id, role, created_at, updated_at)
VALUES ('password_user_1', 'admin', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
