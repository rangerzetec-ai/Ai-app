// Removed lucide-react to eliminate potential import issues
// import { Building2 } from "lucide-react";

export default function SimpleApp() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-md w-full mx-auto text-center">
        <div className="bg-white/90 backdrop-blur-sm border border-slate-200/60 rounded-3xl p-8 shadow-xl">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <span className="text-white text-3xl">🏗️</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">PierPro</h2>
          <p className="text-slate-600 mb-6">Foundation Repair CRM</p>
          <div className="space-y-4">
            <button className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
              Get Started
            </button>
            <p className="text-sm text-slate-500">
              Professional foundation repair management
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
