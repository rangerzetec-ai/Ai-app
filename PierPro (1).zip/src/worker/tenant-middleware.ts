import { Context } from "hono";
import type { UserWithRole } from "./auth";

export interface TenantContext {
  tenant: {
    id: number;
    name: string;
    slug: string;
    domain?: string;
    subscription_plan: string;
    is_active: boolean;
    settings?: any;
  };
  userTenantRole: string;
}

export interface EnhancedContext extends Context {
  get: ((key: 'user') => UserWithRole) & 
       ((key: 'tenant') => TenantContext['tenant']) & 
       ((key: 'userTenantRole') => string);
  set: ((key: 'tenant', value: TenantContext['tenant']) => void) & 
       ((key: 'userTenantRole', value: string) => void);
}

// Get tenant from request (subdomain, domain, or header)
export async function getTenantFromRequest(c: Context, db: any): Promise<TenantContext['tenant'] | null> {
  try {
    // Try to get tenant from subdomain
    const host = c.req.header('host') || '';
    const subdomain = host.split('.')[0];
    
    // Try tenant header first (for API calls)
    const tenantSlug = c.req.header('x-tenant-slug') || subdomain;
    
    if (tenantSlug && tenantSlug !== 'www' && tenantSlug !== 'api') {
      const tenant = await db.prepare(`
        SELECT * FROM tenants 
        WHERE (slug = ? OR domain = ?) AND is_active = TRUE
      `).bind(tenantSlug, host).first();
      
      if (tenant) {
        return {
          id: tenant.id,
          name: tenant.name,
          slug: tenant.slug,
          domain: tenant.domain,
          subscription_plan: tenant.subscription_plan,
          is_active: tenant.is_active,
          settings: tenant.settings ? JSON.parse(tenant.settings) : null
        };
      }
    }
    
    // Fallback to default tenant
    const defaultTenant = await db.prepare(`
      SELECT * FROM tenants WHERE slug = 'default' AND is_active = TRUE
    `).first();
    
    if (defaultTenant) {
      return {
        id: defaultTenant.id,
        name: defaultTenant.name,
        slug: defaultTenant.slug,
        domain: defaultTenant.domain,
        subscription_plan: defaultTenant.subscription_plan,
        is_active: defaultTenant.is_active,
        settings: defaultTenant.settings ? JSON.parse(defaultTenant.settings) : null
      };
    }
    
    return null;
  } catch (error) {
    console.error("Failed to get tenant from request:", error);
    return null;
  }
}

// Get user's role in the current tenant
export async function getUserTenantRole(db: any, userId: string, tenantId: number): Promise<string> {
  try {
    const tenantUser = await db.prepare(`
      SELECT role FROM tenant_users 
      WHERE user_id = ? AND tenant_id = ? AND is_active = TRUE
    `).bind(userId, tenantId).first();
    
    return tenantUser?.role || 'user';
  } catch (error) {
    console.error("Failed to get user tenant role:", error);
    return 'user';
  }
}

// Multi-tenant middleware
export const tenantMiddleware = async (c: any, next: any) => {
  const user = c.get("user") as UserWithRole;
  
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  // Get tenant from request
  const tenant = await getTenantFromRequest(c, c.env.DB);
  
  if (!tenant) {
    return c.json({ error: "Invalid tenant" }, 400);
  }
  
  // Get user's role in this tenant
  const userTenantRole = await getUserTenantRole(c.env.DB, user.id, tenant.id);
  
  // Check if user has access to this tenant
  const hasAccess = await c.env.DB.prepare(`
    SELECT 1 FROM tenant_users 
    WHERE user_id = ? AND tenant_id = ? AND is_active = TRUE
  `).bind(user.id, tenant.id).first();
  
  if (!hasAccess) {
    return c.json({ error: "Access denied to this tenant" }, 403);
  }
  
  // Set tenant context
  c.set("tenant", tenant);
  c.set("userTenantRole", userTenantRole);
  
  await next();
};

// Tenant-aware role checking
export const requireTenantRole = (requiredRoles: string[]) => {
  return async (c: any, next: any) => {
    const userTenantRole = c.get("userTenantRole") as string;
    
    if (!requiredRoles.includes(userTenantRole)) {
      return c.json({ error: "Insufficient tenant permissions" }, 403);
    }
    
    await next();
  };
};

// Helper to add tenant filter to queries
export function addTenantFilter(baseQuery: string, tenantId: number, alias?: string): { query: string; params: any[] } {
  const tableAlias = alias ? `${alias}.` : '';
  const query = baseQuery.includes('WHERE') 
    ? `${baseQuery} AND ${tableAlias}tenant_id = ?`
    : `${baseQuery} WHERE ${tableAlias}tenant_id = ?`;
  
  return { query, params: [tenantId] };
}

// Server-side rendering helper for tenant data
export async function renderTenantData(db: any, tenantId: number, dataType: string, options: any = {}) {
  const { page = 1, limit = 20, search = '' } = options;
  const offset = (page - 1) * limit;
  
  try {
    let baseQuery = '';
    let countQuery = '';
    
    switch (dataType) {
      case 'dashboard':
        // Server-side dashboard data aggregation
        const dashboardData = await db.prepare(`
          SELECT 
            (SELECT COUNT(*) FROM leads WHERE tenant_id = ?) as total_leads,
            (SELECT COUNT(*) FROM leads WHERE tenant_id = ? AND status NOT IN ('unqualified')) as active_leads,
            (SELECT COUNT(*) FROM appointments WHERE tenant_id = ?) as total_appointments,
            (SELECT COUNT(*) FROM appointments WHERE tenant_id = ? AND status = 'completed') as completed_appointments,
            (SELECT COUNT(*) FROM clients WHERE tenant_id = ?) as total_clients,
            (SELECT COUNT(*) FROM projects WHERE tenant_id = ?) as total_projects,
            (SELECT COUNT(*) FROM projects WHERE tenant_id = ? AND status IN ('planning', 'in_progress')) as active_projects,
            (SELECT COALESCE(SUM(amount), 0) FROM project_revenues pr JOIN projects p ON pr.project_id = p.id WHERE p.tenant_id = ?) as total_revenue,
            (SELECT COALESCE(SUM(amount), 0) FROM project_expenses pe JOIN projects p ON pe.project_id = p.id WHERE p.tenant_id = ?) as total_expenses
        `).bind(tenantId, tenantId, tenantId, tenantId, tenantId, tenantId, tenantId, tenantId, tenantId).first();
        
        // Get recent items
        const recentLeads = await db.prepare(`
          SELECT * FROM leads WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 5
        `).bind(tenantId).all();
        
        const upcomingAppointments = await db.prepare(`
          SELECT a.*, l.first_name || ' ' || l.last_name as lead_name
          FROM appointments a
          LEFT JOIN leads l ON a.lead_id = l.id
          WHERE a.tenant_id = ? AND a.appointment_date > datetime('now') AND a.status IN ('scheduled', 'confirmed')
          ORDER BY a.appointment_date ASC LIMIT 5
        `).bind(tenantId).all();
        
        return {
          metrics: dashboardData,
          recentLeads: recentLeads.results,
          upcomingAppointments: upcomingAppointments.results
        };
        
      case 'clients':
        baseQuery = `SELECT * FROM clients`;
        countQuery = `SELECT COUNT(*) as total FROM clients`;
        break;
        
      case 'leads':
        baseQuery = `
          SELECT l.*, sp.first_name || ' ' || sp.last_name as sales_person_name
          FROM leads l
          LEFT JOIN sales_people sp ON l.assigned_sales_person_id = sp.id
        `;
        countQuery = `SELECT COUNT(*) as total FROM leads`;
        break;
        
      case 'appointments':
        baseQuery = `
          SELECT 
            a.*,
            l.first_name || ' ' || l.last_name as lead_name,
            c.first_name || ' ' || c.last_name as client_name,
            sp.first_name || ' ' || sp.last_name as sales_person_name
          FROM appointments a
          LEFT JOIN leads l ON a.lead_id = l.id
          LEFT JOIN clients c ON a.client_id = c.id
          LEFT JOIN sales_people sp ON a.assigned_sales_person_id = sp.id
        `;
        countQuery = `SELECT COUNT(*) as total FROM appointments`;
        break;
        
      default:
        if (dataType !== 'dashboard') {
          throw new Error(`Unsupported data type: ${dataType}`);
        }
        break;
    }
    
    // Dashboard data is returned above
    // This shouldn't be reached for dashboard type
    
    // Add tenant filter
    const tenantFilteredQuery = addTenantFilter(baseQuery, tenantId);
    const tenantFilteredCountQuery = addTenantFilter(countQuery, tenantId);
    
    // Add search filter if provided
    let finalQuery = tenantFilteredQuery.query;
    let finalCountQuery = tenantFilteredCountQuery.query;
    const queryParams = [...tenantFilteredQuery.params];
    const countParams = [...tenantFilteredCountQuery.params];
    
    if (search && dataType !== 'dashboard') {
      const searchCondition = ` AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)`;
      finalQuery += searchCondition;
      finalCountQuery += searchCondition;
      queryParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
      countParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    // Add pagination
    if (dataType !== 'dashboard') {
      finalQuery += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
      queryParams.push(limit, offset);
    }
    
    // Execute queries
    const [data, countResult] = await Promise.all([
      db.prepare(finalQuery).bind(...queryParams).all(),
      dataType === 'dashboard' ? null : db.prepare(finalCountQuery).bind(...countParams).first()
    ]);
    
    const total = countResult?.total || 0;
    
    return {
      data: data.results,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNextPage: page < Math.ceil(total / limit),
        hasPrevPage: page > 1
      }
    };
  } catch (error) {
    console.error(`Failed to render tenant data for ${dataType}:`, error);
    throw error;
  }
}
