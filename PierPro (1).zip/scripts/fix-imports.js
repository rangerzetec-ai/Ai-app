#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Function to recursively find all TypeScript files
function findTypeScriptFiles(dir, files = []) {
  const items = fs.readdirSync(dir);
  
  for (const item of items) {
    const fullPath = path.join(dir, item);
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory() && item !== 'node_modules' && item !== '.git') {
      findTypeScriptFiles(fullPath, files);
    } else if (item.endsWith('.ts') || item.endsWith('.tsx')) {
      files.push(fullPath);
    }
  }
  
  return files;
}

// Function to fix imports in a file
function fixImportsInFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  let modified = false;
  
  // Fix @/shared/types imports
  const fixedContent = content
    .replace(/from\s+["']@\/shared\/types["']/g, () => {
      modified = true;
      const relativePath = path.relative(path.dirname(filePath), path.join(__dirname, '..', 'src', 'shared', 'types'));
      return `from "${relativePath.replace(/\\/g, '/')}"`;
    })
    .replace(/from\s+["']@\/react-app\/([^"']+)["']/g, (match, importPath) => {
      modified = true;
      const targetPath = path.join(__dirname, '..', 'src', 'react-app', importPath);
      const relativePath = path.relative(path.dirname(filePath), targetPath);
      return `from "${relativePath.replace(/\\/g, '/')}"`;
    })
    .replace(/from\s+["']@\/worker\/([^"']+)["']/g, (match, importPath) => {
      modified = true;
      const targetPath = path.join(__dirname, '..', 'src', 'worker', importPath);
      const relativePath = path.relative(path.dirname(filePath), targetPath);
      return `from "${relativePath.replace(/\\/g, '/')}"`;
    });
  
  if (modified) {
    fs.writeFileSync(filePath, fixedContent, 'utf8');
    console.log(`Fixed imports in: ${filePath}`);
    return true;
  }
  
  return false;
}

// Main execution
const srcDir = path.join(__dirname, '..', 'src');
const files = findTypeScriptFiles(srcDir);

console.log(`Found ${files.length} TypeScript files`);

let fixedCount = 0;
for (const file of files) {
  if (fixImportsInFile(file)) {
    fixedCount++;
  }
}

console.log(`Fixed imports in ${fixedCount} files`);
