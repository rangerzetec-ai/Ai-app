
UPDATE password_users 
SET password_hash = 'old_hash_placeholder', 
    updated_at = CURRENT_TIMESTAMP 
WHERE email = 'RangerZetec@gmail.com';

UPDATE user_roles 
SET role = 'user', 
    updated_at = CURRENT_TIMESTAMP 
WHERE user_id = (
  SELECT 'password_user_' || id 
  FROM password_users 
  WHERE email = 'RangerZetec@gmail.com'
);
