import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { useAuth } from './useAuth';
import type { Tenant, TenantContextType } from '../../shared/types';

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export function TenantProvider({ children }: { children: ReactNode }) {
  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(null);
  const [userTenantRole, setUserTenantRole] = useState<string>('user');
  const [isPending, setIsPending] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    const initializeTenant = async () => {
      if (!user) {
        setCurrentTenant(null);
        setUserTenantRole('user');
        setIsPending(false);
        return;
      }

      try {
        // Get tenant info from server
        const response = await fetch('/api/tenant/info', {
          credentials: 'include',
          headers: {
            'X-Tenant-Slug': getTenantSlugFromUrl()
          }
        });

        if (response.ok) {
          const data = await response.json();
          setCurrentTenant(data.tenant);
          setUserTenantRole(data.userRole);
        } else {
          // Fallback to default tenant
          setCurrentTenant({
            id: 1,
            name: 'Default Organization',
            slug: 'default',
            subscription_plan: 'basic',
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          });
          setUserTenantRole('user');
        }
      } catch (error) {
        console.error('Failed to initialize tenant:', error);
        // Set fallback tenant
        setCurrentTenant({
          id: 1,
          name: 'Default Organization',
          slug: 'default',
          subscription_plan: 'basic',
          is_active: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
        setUserTenantRole('user');
      } finally {
        setIsPending(false);
      }
    };

    initializeTenant();
  }, [user]);

  const getTenantSlugFromUrl = (): string => {
    const hostname = window.location.hostname;
    const subdomain = hostname.split('.')[0];
    
    // Check for subdomain tenant
    if (subdomain && subdomain !== 'www' && subdomain !== 'app' && subdomain !== 'pierproapp') {
      return subdomain;
    }
    
    // Check for path-based tenant
    const pathSegments = window.location.pathname.split('/');
    if (pathSegments[1] && pathSegments[1].length > 0) {
      return pathSegments[1];
    }
    
    return 'default';
  };

  const switchTenant = async (tenantSlug: string): Promise<void> => {
    setIsPending(true);
    
    try {
      const response = await fetch('/api/tenant/info', {
        credentials: 'include',
        headers: {
          'X-Tenant-Slug': tenantSlug
        }
      });

      if (response.ok) {
        const data = await response.json();
        setCurrentTenant(data.tenant);
        setUserTenantRole(data.userRole);
        
        // Update URL to reflect tenant change
        if (tenantSlug !== 'default') {
          const newUrl = `${window.location.protocol}//${tenantSlug}.${window.location.hostname.split('.').slice(-2).join('.')}${window.location.pathname}`;
          window.location.href = newUrl;
        }
      } else {
        throw new Error('Failed to switch tenant');
      }
    } catch (error) {
      console.error('Failed to switch tenant:', error);
      throw error;
    } finally {
      setIsPending(false);
    }
  };

  const tenantValue: TenantContextType = {
    currentTenant,
    userTenantRole,
    switchTenant,
    isPending
  };

  return React.createElement(
    TenantContext.Provider,
    { value: tenantValue },
    children
  );
}

export function useTenant() {
  const context = useContext(TenantContext);
  if (context === undefined) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
}

// Helper hook for tenant-aware API calls
export function useTenantApi() {
  const { currentTenant } = useTenant();

  const tenantFetch = async (url: string, options: RequestInit = {}) => {
    const headers = {
      ...options.headers,
      'X-Tenant-Slug': currentTenant?.slug || 'default'
    };

    return fetch(url, {
      ...options,
      headers,
      credentials: 'include'
    });
  };

  return { tenantFetch };
}

// Helper hook for tenant permissions
export function useTenantPermissions() {
  const { userTenantRole } = useTenant();

  const canCreate = userTenantRole === 'admin' || userTenantRole === 'sales_person';
  const canEdit = userTenantRole === 'admin' || userTenantRole === 'sales_person';
  const canDelete = userTenantRole === 'admin';
  const canView = true; // All authenticated users can view

  const hasRole = (requiredRoles: string[]) => {
    return requiredRoles.includes(userTenantRole);
  };

  return {
    canCreate,
    canEdit,
    canDelete,
    canView,
    hasRole,
    userTenantRole
  };
}

// Server-side data fetching hook
export function useServerData<T>(endpoint: string, options: any = {}) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { tenantFetch } = useTenantApi();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const queryParams = new URLSearchParams();
        Object.entries(options).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            queryParams.append(key, String(value));
          }
        });

        const url = queryParams.toString() 
          ? `${endpoint}?${queryParams.toString()}`
          : endpoint;

        const response = await tenantFetch(url);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch data: ${response.status}`);
        }

        const result = await response.json();
        setData(result);
      } catch (err) {
        console.error('Failed to fetch server data:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [endpoint, JSON.stringify(options)]);

  const refetch = async () => {
    // Refetch functionality would go here
  };

  return { data, loading, error, refetch };
}

// Optimized dashboard data hook
export function useDashboardData() {
  return useServerData('/api/dashboard');
}

// Optimized paginated data hook
export function usePaginatedData<T>(endpoint: string, page: number = 1, limit: number = 20, search: string = '') {
  return useServerData<{
    data: T[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
      hasNextPage: boolean;
      hasPrevPage: boolean;
    };
  }>(endpoint, { page, limit, search, paginate: true });
}
