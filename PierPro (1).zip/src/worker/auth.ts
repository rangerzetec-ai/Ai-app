import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  deleteSession,
  getCurrentUser,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import type { MochaUser } from "@getmocha/users-service/shared";
import * as bcrypt from "bcryptjs";

interface Env {
  DB: any;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
}

export type UserRole = 'admin' | 'sales_person' | 'user';

export interface UserWithRole extends MochaUser {
  role: UserRole;
}

// Helper function to get user role from database
export async function getUserRole(db: any, userId: string): Promise<UserRole> {
  try {
    const result = await db.prepare("SELECT role FROM user_roles WHERE user_id = ?")
      .bind(userId).first();
    
    return (result?.role as UserRole) || 'user';
  } catch (error) {
    console.error("Failed to get user role:", error);
    return 'user';
  }
}

// Helper function to get password user by email
export async function getPasswordUserByEmail(db: any, email: string) {
  try {
    console.log("Looking up user with email:", email);
    const result = await db.prepare("SELECT * FROM password_users WHERE email = ? AND is_active = TRUE")
      .bind(email).first();
    console.log("Database query result:", result ? "User found" : "User not found");
    return result;
  } catch (error) {
    console.error("Failed to get password user:", error);
    return null;
  }
}

// Helper function to create password user session
export function createPasswordUserSession(user: any): string {
  // Create a simple session token for password users
  const sessionData = {
    type: 'password',
    userId: `password_user_${user.id}`,
    email: user.email,
    name: user.name,
    timestamp: Date.now()
  };
  
  // Use TextEncoder/TextDecoder for Cloudflare Workers compatibility
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const bytes = encoder.encode(JSON.stringify(sessionData));
  return btoa(decoder.decode(bytes));
}

// Helper function to validate password user session
export function validatePasswordUserSession(sessionToken: string): any | null {
  try {
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();
    const decodedBytes = encoder.encode(atob(sessionToken));
    const sessionData = JSON.parse(decoder.decode(decodedBytes));
    
    if (sessionData.type !== 'password') {
      return null;
    }
    
    // Check if session is not too old (24 hours)
    const maxAge = 24 * 60 * 60 * 1000;
    if (Date.now() - sessionData.timestamp > maxAge) {
      return null;
    }
    
    return {
      id: sessionData.userId,
      email: sessionData.email,
      name: sessionData.name
    };
  } catch (error) {
    return null;
  }
}

// Helper function to set user role
export async function setUserRole(db: any, userId: string, role: UserRole): Promise<void> {
  try {
    await db.prepare(`
      INSERT INTO user_roles (user_id, role, created_at, updated_at)
      VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      ON CONFLICT(user_id) DO UPDATE SET
        role = excluded.role,
        updated_at = CURRENT_TIMESTAMP
    `).bind(userId, role).run();
  } catch (error) {
    console.error("Failed to set user role:", error);
    throw error;
  }
}

// Extended auth middleware that includes role information
export const authWithRoleMiddleware = async (c: any, next: any) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
  
  if (!sessionToken) {
    return c.json({ error: "Authentication required" }, 401);
  }

  try {
    // First try to validate as password user session
    const passwordUser = validatePasswordUserSession(sessionToken);
    
    if (passwordUser) {
      // Get user role from database
      const role = await getUserRole(c.env.DB, passwordUser.id);
      
      // Set user with role in context (adapt to MochaUser-like structure)
      c.set("user", { 
        id: passwordUser.id,
        email: passwordUser.email,
        google_user_data: {
          name: passwordUser.name,
          email: passwordUser.email
        },
        role 
      } as UserWithRole);
      
      await next();
      return;
    }

    // If not a password user, try Google OAuth user
    const oauthUser = await getCurrentUser(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    if (!oauthUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    // Get user role from database
    const role = await getUserRole(c.env.DB, oauthUser.id);
    
    // Set user with role in context
    c.set("user", { ...oauthUser, role } as UserWithRole);
    
    await next();
  } catch (error) {
    console.error("Auth middleware error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
};

// Role-based access control middleware
export const requireRole = (requiredRoles: UserRole[]) => {
  return async (c: any, next: any) => {
    const user = c.get("user") as UserWithRole;
    
    if (!user) {
      return c.json({ error: "Authentication required" }, 401);
    }
    
    if (!requiredRoles.includes(user.role)) {
      return c.json({ error: "Insufficient permissions" }, 403);
    }
    
    await next();
  };
};

// Helper functions for role checking (can be used in components if needed)
export const canDelete = (user: UserWithRole): boolean => {
  return user.role === 'admin';
};

export const canAddEdit = (user: UserWithRole): boolean => {
  return user.role === 'admin' || user.role === 'sales_person';
};

export const canView = (_user: UserWithRole): boolean => {
  return true; // All authenticated users can view
};

const app = new Hono<{ Bindings: Env }>();

// Get OAuth redirect URL
app.get('/api/oauth/google/redirect_url', async (c) => {
  try {
    const redirectUrl = await getOAuthRedirectUrl('google', {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    return c.json({ redirectUrl }, 200);
  } catch (error) {
    console.error("Failed to get OAuth redirect URL:", error);
    return c.json({ error: "Failed to get login URL" }, 500);
  }
});

// Exchange code for session token
app.post("/api/sessions", async (c) => {
  try {
    const body = await c.req.json();

    if (!body.code) {
      return c.json({ error: "No authorization code provided" }, 400);
    }

    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      secure: false, // Set to false for local development
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error("Failed to exchange code for session:", error);
    return c.json({ error: "Authentication failed" }, 500);
  }
});

// Get current user with role
app.get("/api/users/me", authWithRoleMiddleware, async (c) => {
  return c.json(c.get("user"));
});

// Email/Password Login
app.post("/api/auth/login", async (c) => {
  try {
    const { email, password } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    console.log("Login attempt for email:", email);

    // Get user from database
    const dbUser = await getPasswordUserByEmail(c.env.DB, email);
    
    if (!dbUser) {
      console.log("User not found for email:", email);
      return c.json({ error: "Invalid email or password" }, 401);
    }

    console.log("User found, verifying password");

    // Verify password
    const isValid = await bcrypt.compare(password, dbUser.password_hash);
    
    if (!isValid) {
      console.log("Password verification failed");
      return c.json({ error: "Invalid email or password" }, 401);
    }

    console.log("Password verified successfully");

    // Create session token
    const sessionToken = createPasswordUserSession(dbUser);

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      secure: false, // Allow for development
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ 
      success: true,
      user: {
        id: `password_user_${dbUser.id}`,
        email: dbUser.email,
        name: dbUser.name
      }
    }, 200);
  } catch (error) {
    console.error("Login error:", error);
    return c.json({ error: "Login failed" }, 500);
  }
});

// Email/Password Registration
app.post("/api/auth/register", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    if (password.length < 6) {
      return c.json({ error: "Password must be at least 6 characters" }, 400);
    }

    console.log("Registration attempt for email:", email);

    // Check if user already exists
    const existingUser = await getPasswordUserByEmail(c.env.DB, email);
    
    if (existingUser) {
      console.log("User already exists with email:", email);
      return c.json({ error: "User with this email already exists" }, 409);
    }

    // Hash password
    console.log("Hashing password...");
    const passwordHash = await bcrypt.hash(password, 10);
    console.log("Password hashed successfully");

    // Create user
    const createUserStmt = c.env.DB.prepare(`
      INSERT INTO password_users (email, password_hash, name, is_active, created_at, updated_at)
      VALUES (?, ?, ?, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `);

    console.log("Creating user in database...");
    const userResult = await createUserStmt.bind(email, passwordHash, name || null).run();

    if (!userResult.success) {
      console.error("Failed to create user in database");
      return c.json({ error: "Failed to create user" }, 500);
    }

    console.log("User created successfully with ID:", userResult.meta.last_row_id);

    const userId = `password_user_${userResult.meta.last_row_id}`;

    // Create default user role
    await setUserRole(c.env.DB, userId, 'user');

    return c.json({ 
      success: true,
      message: "User created successfully"
    }, 201);
  } catch (error) {
    console.error("Registration error:", error);
    return c.json({ error: "Registration failed" }, 500);
  }
});

// Logout
app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    // Check if it's a password user session
    const passwordUser = validatePasswordUserSession(sessionToken);
    
    if (!passwordUser) {
      // It's a Google OAuth session, delete it properly
      try {
        await deleteSession(sessionToken, {
          apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
          apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
        });
      } catch (error) {
        console.error("Failed to delete session:", error);
      }
    }
    // For password users, we just delete the cookie (no server-side session storage)
  }

  // Delete cookie
  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'lax',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Admin-only: Manage user roles
app.get('/api/users', authWithRoleMiddleware, requireRole(['admin']), async (c) => {
  try {
    const users = await c.env.DB.prepare(`
      SELECT user_id, role, created_at, updated_at
      FROM user_roles
      ORDER BY created_at DESC
    `).all();
    
    return c.json(users.results);
  } catch (error) {
    console.error("Failed to fetch users:", error);
    return c.json({ error: "Failed to fetch users" }, 500);
  }
});

app.put('/api/users/:userId/role', authWithRoleMiddleware, requireRole(['admin']), async (c) => {
  try {
    const userId = c.req.param("userId");
    const { role } = await c.req.json();
    
    if (!['admin', 'sales_person', 'user'].includes(role)) {
      return c.json({ error: "Invalid role" }, 400);
    }
    
    await setUserRole(c.env.DB, userId, role);
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Failed to update user role:", error);
    return c.json({ error: "Failed to update user role" }, 500);
  }
});

export default app;
