import { Building2 } from "lucide-react";

interface LoadingFallbackProps {
  message?: string;
  error?: Error | null;
}

export default function LoadingFallback({ message = "Loading...", error }: LoadingFallbackProps) {
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 via-white to-red-50">
        <div className="max-w-md w-full mx-auto text-center">
          <div className="bg-white/90 backdrop-blur-sm border border-red-200 rounded-3xl p-8 shadow-xl">
            <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <span className="text-red-600 text-2xl">⚠️</span>
            </div>
            <h2 className="text-xl font-semibold text-slate-900 mb-2">Loading Error</h2>
            <p className="text-slate-600 mb-4">
              {error.message || "Something went wrong while loading the application"}
            </p>
            <div className="space-y-2">
              <button
                onClick={() => window.location.reload()}
                className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Reload Page
              </button>
              <button
                onClick={() => {
                  localStorage.clear();
                  sessionStorage.clear();
                  window.location.reload();
                }}
                className="w-full px-4 py-2 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors text-sm"
              >
                Clear Cache & Reload
              </button>
            </div>
            <details className="mt-4 text-left">
              <summary className="cursor-pointer text-sm text-red-700 hover:text-red-800">
                Technical Details
              </summary>
              <div className="mt-2 p-3 bg-red-50 rounded text-xs text-red-800 font-mono overflow-auto max-h-32">
                {error.stack || error.message}
              </div>
            </details>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-md w-full mx-auto text-center">
        <div className="bg-white/90 backdrop-blur-sm border border-slate-200/60 rounded-3xl p-8 shadow-xl">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-slate-900 mb-2">PierPro</h2>
          <p className="text-slate-600">{message}</p>
        </div>
      </div>
    </div>
  );
}
