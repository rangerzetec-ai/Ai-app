
-- Create a default admin user for testing
INSERT OR IGNORE INTO password_users (email, password_hash, name, is_active, created_at, updated_at)
VALUES ('admin@pierpro.com', '$2a$10$Q3DqQrFfxXpJN2hQ8zGGGeQgR7Nz1Y1CzKJGX8nYr5cMwQzGqrHHS', 'Admin User', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- The password for the above user is 'admin123'
