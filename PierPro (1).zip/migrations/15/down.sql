
-- Remove indexes
DROP INDEX IF EXISTS idx_clients_tenant_id;
DROP INDEX IF EXISTS idx_projects_tenant_id;
DROP INDEX IF EXISTS idx_leads_tenant_id;
DROP INDEX IF EXISTS idx_appointments_tenant_id;
DROP INDEX IF EXISTS idx_sales_people_tenant_id;
DROP INDEX IF EXISTS idx_appointment_photos_tenant_id;
DROP INDEX IF EXISTS idx_project_expenses_tenant_id;
DROP INDEX IF EXISTS idx_project_revenues_tenant_id;
DROP INDEX IF EXISTS idx_tenant_users_tenant_user;

-- Drop tenant_users table
DROP TABLE tenant_users;

-- Remove tenant_id columns from all tables
ALTER TABLE project_workflows DROP COLUMN tenant_id;
ALTER TABLE notification_contacts DROP COLUMN tenant_id;
ALTER TABLE engineers DROP COLUMN tenant_id;
ALTER TABLE project_revenues DROP COLUMN tenant_id;
ALTER TABLE project_expenses DROP COLUMN tenant_id;
ALTER TABLE expense_categories DROP COLUMN tenant_id;
ALTER TABLE project_financials DROP COLUMN tenant_id;
ALTER TABLE appointment_photos DROP COLUMN tenant_id;
ALTER TABLE sales_people DROP COLUMN tenant_id;
ALTER TABLE appointments DROP COLUMN tenant_id;
ALTER TABLE leads DROP COLUMN tenant_id;
ALTER TABLE projects DROP COLUMN tenant_id;
ALTER TABLE clients DROP COLUMN tenant_id;

-- Drop tenants table
DROP TABLE tenants;
