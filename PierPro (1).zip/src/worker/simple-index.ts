import { Hono } from "hono";
import { cors } from "hono/cors";
import { zValidator } from "@hono/zod-validator";
import authApp, { authWithRoleMiddleware } from "./auth";
import debugAuthApp from "./debug-auth";
import {
  CreateClientSchema,
  CreateLeadSchema,
  CreateAppointmentSchema,
  UpdateAppointmentSchema,
} from "../shared/types";

interface Env {
  DB: D1Database;
  R2_BUCKET: R2Bucket;
  GOOGLE_MAPS_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
}

const app = new Hono<{ Bindings: Env }>();

// Enable CORS
app.use("*", cors({
  origin: "*",
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
}));

// Mount auth routes
app.route("/", authApp);

// Mount debug auth routes (for development)
app.route("/", debugAuthApp);

// Health check
app.get("/api/health", (c) => {
  return c.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Google Maps API configuration
app.get("/api/config/google-maps", (c) => {
  try {
    const apiKey = c.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      return c.json({ error: "Google Maps API key not configured" }, 500);
    }
    return c.json({ apiKey });
  } catch (error) {
    console.error("Failed to get Google Maps config:", error);
    return c.json({ error: "Failed to get configuration" }, 500);
  }
});

// Simple dashboard endpoint
app.get("/api/dashboard", authWithRoleMiddleware, async (c) => {
  try {
    const metrics = await c.env.DB.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM leads) as total_leads,
        (SELECT COUNT(*) FROM leads WHERE status NOT IN ('unqualified')) as active_leads,
        (SELECT COUNT(*) FROM appointments) as total_appointments,
        (SELECT COUNT(*) FROM appointments WHERE status = 'completed') as completed_appointments,
        (SELECT COUNT(*) FROM clients) as total_clients,
        (SELECT COUNT(*) FROM projects) as total_projects,
        (SELECT COUNT(*) FROM projects WHERE status IN ('planning', 'in_progress')) as active_projects,
        0 as total_revenue,
        0 as total_expenses
    `).first();
    
    const recentLeads = await c.env.DB.prepare(`
      SELECT * FROM leads ORDER BY created_at DESC LIMIT 5
    `).all();
    
    const upcomingAppointments = await c.env.DB.prepare(`
      SELECT a.*, l.first_name || ' ' || l.last_name as lead_name
      FROM appointments a
      LEFT JOIN leads l ON a.lead_id = l.id
      WHERE a.appointment_date > datetime('now') AND a.status IN ('scheduled', 'confirmed')
      ORDER BY a.appointment_date ASC LIMIT 5
    `).all();
    
    return c.json({
      metrics,
      recentLeads: recentLeads.results,
      upcomingAppointments: upcomingAppointments.results
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return c.json({ error: "Failed to fetch dashboard data" }, 500);
  }
});

// Clients endpoints
app.get("/api/clients", authWithRoleMiddleware, async (c) => {
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM clients ORDER BY created_at DESC");
    const result = await stmt.all();
    return c.json(result.results);
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to fetch clients" }, 500);
  }
});

app.get("/api/clients/:id", authWithRoleMiddleware, async (c) => {
  try {
    const id = c.req.param("id");
    const stmt = c.env.DB.prepare("SELECT * FROM clients WHERE id = ?");
    const result = await stmt.bind(id).first();
    
    if (!result) {
      return c.json({ error: "Client not found" }, 404);
    }
    
    return c.json(result);
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to fetch client" }, 500);
  }
});

app.post("/api/clients", authWithRoleMiddleware, zValidator("json", CreateClientSchema), async (c) => {
  try {
    const data = c.req.valid("json");
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO clients (
        first_name, last_name, email, phone, address_line1, address_line2, 
        city, state, zip_code, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `);
    
    const result = await stmt.bind(
      data.first_name,
      data.last_name,
      data.email || null,
      data.phone || null,
      data.address_line1 || null,
      data.address_line2 || null,
      data.city || null,
      data.state || null,
      data.zip_code || null,
      data.notes || null
    ).run();
    
    if (result.success) {
      const newClient = await c.env.DB.prepare("SELECT * FROM clients WHERE id = ?")
        .bind(result.meta.last_row_id).first();
      return c.json(newClient, 201);
    } else {
      return c.json({ error: "Failed to create client" }, 500);
    }
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to create client" }, 500);
  }
});

// Leads endpoints
app.get("/api/leads", authWithRoleMiddleware, async (c) => {
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM leads ORDER BY created_at DESC");
    const result = await stmt.all();
    return c.json(result.results);
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to fetch leads" }, 500);
  }
});

app.post("/api/leads", authWithRoleMiddleware, zValidator("json", CreateLeadSchema), async (c) => {
  try {
    const data = c.req.valid("json");
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO leads (
        first_name, last_name, email, phone, address_line1, address_line2, 
        city, state, zip_code, notes, source, status, site_photos, 
        improvement_sketch_url, improvement_sketch_filename, assigned_sales_person_id,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `);
    
    const result = await stmt.bind(
      data.first_name,
      data.last_name,
      data.email || null,
      data.phone || null,
      data.address_line1 || null,
      data.address_line2 || null,
      data.city || null,
      data.state || null,
      data.zip_code || null,
      data.notes || null,
      data.source || null,
      data.status || "new",
      data.site_photos || null,
      data.improvement_sketch_url || null,
      data.improvement_sketch_filename || null,
      data.assigned_sales_person_id || null
    ).run();
    
    if (result.success) {
      const newLead = await c.env.DB.prepare("SELECT * FROM leads WHERE id = ?")
        .bind(result.meta.last_row_id).first();
      return c.json(newLead, 201);
    } else {
      return c.json({ error: "Failed to create lead" }, 500);
    }
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to create lead" }, 500);
  }
});

// Appointments endpoints
app.get("/api/appointments", authWithRoleMiddleware, async (c) => {
  try {
    const stmt = c.env.DB.prepare(`
      SELECT 
        a.*,
        l.first_name as lead_first_name,
        l.last_name as lead_last_name,
        l.email as lead_email,
        l.phone as lead_phone,
        l.status as lead_status,
        cl.first_name as client_first_name,
        cl.last_name as client_last_name
      FROM appointments a
      LEFT JOIN leads l ON a.lead_id = l.id
      LEFT JOIN clients cl ON a.client_id = cl.id
      ORDER BY a.appointment_date DESC
    `);
    
    const result = await stmt.all();
    return c.json(result.results);
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to fetch appointments" }, 500);
  }
});

app.get("/api/appointments/:id", authWithRoleMiddleware, async (c) => {
  try {
    const id = c.req.param("id");
    const stmt = c.env.DB.prepare("SELECT * FROM appointments WHERE id = ?");
    const result = await stmt.bind(id).first();
    
    if (!result) {
      return c.json({ error: "Appointment not found" }, 404);
    }
    
    return c.json(result);
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to fetch appointment" }, 500);
  }
});

app.post("/api/appointments", authWithRoleMiddleware, zValidator("json", CreateAppointmentSchema), async (c) => {
  try {
    const data = c.req.valid("json");
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO appointments (
        lead_id, appointment_date, appointment_type, status, notes, location_address, 
        duration_minutes, site_photos, improvement_sketch_url, improvement_sketch_filename,
        technician_notes, generated_model_data, pier_placements, assigned_sales_person_id,
        foundation_type, pier_type, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `);
    
    const result = await stmt.bind(
      data.lead_id,
      data.appointment_date,
      data.appointment_type || "consultation",
      data.status || "scheduled",
      data.notes || null,
      data.location_address || null,
      data.duration_minutes || 60,
      data.site_photos || null,
      data.improvement_sketch_url || null,
      data.improvement_sketch_filename || null,
      data.technician_notes || null,
      null, // generated_model_data
      null, // pier_placements
      data.assigned_sales_person_id || null,
      data.foundation_type || null,
      data.pier_type || null
    ).run();
    
    if (result.success) {
      const newAppointment = await c.env.DB.prepare("SELECT * FROM appointments WHERE id = ?")
        .bind(result.meta.last_row_id).first();
      return c.json(newAppointment, 201);
    } else {
      return c.json({ error: "Failed to create appointment" }, 500);
    }
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to create appointment" }, 500);
  }
});

app.put("/api/appointments/:id", authWithRoleMiddleware, zValidator("json", UpdateAppointmentSchema), async (c) => {
  try {
    const id = c.req.param("id");
    const data = c.req.valid("json");
    
    const updates: string[] = [];
    const values: any[] = [];
    
    Object.entries(data).forEach(([key, value]) => {
      if (value !== undefined && key !== 'id' && key !== 'created_at') {
        updates.push(`${key} = ?`);
        values.push(value);
      }
    });
    
    if (updates.length === 0) {
      updates.push("updated_at = CURRENT_TIMESTAMP");
      values.push(id);
    } else {
      updates.push("updated_at = CURRENT_TIMESTAMP");
      values.push(id);
    }
    
    const stmt = c.env.DB.prepare(`UPDATE appointments SET ${updates.join(", ")} WHERE id = ?`);
    const result = await stmt.bind(...values).run();
    
    if (result.success) {
      const updatedAppointment = await c.env.DB.prepare("SELECT * FROM appointments WHERE id = ?")
        .bind(id).first();
      return c.json(updatedAppointment);
    } else {
      return c.json({ error: "Appointment not found" }, 404);
    }
  } catch (error) {
    console.error("Database error:", error);
    return c.json({ error: "Failed to update appointment" }, 500);
  }
});

// 3D model generation endpoint
app.post("/api/appointments/:id/generate-3d-model", authWithRoleMiddleware, async (c) => {
  try {
    const id = c.req.param("id");
    
    const appointment = await c.env.DB.prepare("SELECT * FROM appointments WHERE id = ?").bind(id).first();
    if (!appointment) {
      return c.json({ error: "Appointment not found" }, 404);
    }
    
    // Handle optional request data for 3D generation
    
    // Mock 3D model generation
    const modelData = {
      generated: true,
      timestamp: new Date().toISOString(),
      source_photos: [],
      model_url: `appointment-${id}-${Date.now()}.json`,
      processing_time: `${(1.8 + Math.random() * 1.5).toFixed(1)}s`,
      confidence: 0.95,
      foundation_dimensions: {
        length: 18,
        width: 13,
        estimated_depth: 6
      }
    };
    
    const stmt = c.env.DB.prepare(`
      UPDATE appointments 
      SET generated_model_data = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `);
    
    const result = await stmt.bind(JSON.stringify(modelData), id).run();
    
    if (result.success) {
      return c.json({ 
        model_data: modelData, 
        success: true,
        message: "3D presentation generated successfully!" 
      });
    } else {
      return c.json({ error: "Failed to save generated presentation data" }, 500);
    }
  } catch (error) {
    console.error("3D generation error:", error);
    return c.json({ 
      error: "Failed to generate 3D model", 
      details: error instanceof Error ? error.message : String(error) 
    }, 500);
  }
});

// File serving
app.get("/api/files/:filename", authWithRoleMiddleware, async (c) => {
  try {
    const filename = c.req.param("filename");
    
    const ifNoneMatch = c.req.header("if-none-match");
    const object = await c.env.R2_BUCKET.get(filename);
    
    if (object === null) {
      return c.json({ error: "File not found" }, 404);
    }
    
    if (ifNoneMatch === object.httpEtag) {
      return new Response(null, { status: 304 });
    }
    
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    headers.set("cache-control", "public, max-age=31536000, immutable");
    
    return new Response(object.body, { headers });
  } catch (error) {
    console.error("File serving error:", error);
    return c.json({ error: "Failed to serve file" }, 500);
  }
});

// 404 handler
app.notFound((c) => {
  return c.json({ error: "Not found" }, 404);
});

// Error handler
app.onError((err, c) => {
  console.error("Global error handler:", err);
  return c.json({ error: "Internal server error" }, 500);
});

export default app;
