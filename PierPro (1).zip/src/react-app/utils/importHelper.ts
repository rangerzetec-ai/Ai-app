// Helper to prevent circular imports and reduce bundle size
export const dynamicImport = async (path: string) => {
  try {
    return await import(path);
  } catch (error) {
    console.warn(`Failed to dynamically import ${path}:`, error);
    return null;
  }
};

// Debounce helper for performance
export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

// Memory cleanup helper
export const cleanupComponent = (cleanup: () => void) => {
  return () => {
    try {
      cleanup();
    } catch (error) {
      console.warn('Cleanup error:', error);
    }
  };
};
