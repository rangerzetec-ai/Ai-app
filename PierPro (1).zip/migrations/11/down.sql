
DELETE FROM user_roles WHERE user_id = 'password_user_1';
DROP INDEX idx_password_users_email;
DROP TABLE password_users;
