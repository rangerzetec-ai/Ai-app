import { useState } from "react";
import { Save, X, UserPlus } from "lucide-react";
import { CreateLead, UpdateLead, Lead } from "@/shared/types";
import { FormSection, FormField, StandardTextarea } from "./shared/FormField";
import ContactInfoSection from "./shared/ContactInfoSection";
import AddressInfoSection from "./shared/AddressInfoSection";
import SalesPersonSection from "./shared/SalesPersonSection";

interface LeadFormProps {
  lead?: Lead;
  onSubmit: (data: CreateLead | UpdateLead) => Promise<void>;
  onCancel: () => void;
  isEditing: boolean;
}

export default function LeadForm({ lead, onSubmit, onCancel, isEditing }: LeadFormProps) {
  const [formData, setFormData] = useState({
    first_name: lead?.first_name || "",
    last_name: lead?.last_name || "",
    email: lead?.email || "",
    phone: lead?.phone || "",
    address_line1: lead?.address_line1 || "",
    address_line2: lead?.address_line2 || "",
    city: lead?.city || "",
    state: lead?.state || "",
    zip_code: lead?.zip_code || "",
    notes: lead?.notes || "",
    source: lead?.source || "",
    status: lead?.status || "new",
    assigned_sales_person_id: lead?.assigned_sales_person_id?.toString() || "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.first_name.trim()) {
      newErrors.first_name = "First name is required";
    }
    
    if (!formData.last_name.trim()) {
      newErrors.last_name = "Last name is required";
    }
    
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Invalid email format";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setSaving(true);
    try {
      // Filter out empty strings for optional fields
      const submitData = Object.fromEntries(
        Object.entries(formData).map(([key, value]) => [
          key,
          key === "assigned_sales_person_id" 
            ? (value && value !== "" ? parseInt(value.toString()) : undefined)
            : (value === "" ? undefined : value)
        ])
      );
      
      await onSubmit(submitData);
    } catch (error) {
      console.error("Failed to save lead:", error);
      setErrors({ general: "Failed to save lead. Please try again." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl p-6">
      <form onSubmit={handleSubmit} className="space-y-8">
        {errors.general && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">{errors.general}</p>
          </div>
        )}

        <FormSection title="Lead Information" icon={<UserPlus className="w-5 h-5 text-purple-600" />}>
          {/* Contact Information */}
          <ContactInfoSection 
            data={formData}
            onChange={handleChange}
            errors={errors}
            required={{ first_name: true, last_name: true }}
          />

          {/* Address Information */}
          <AddressInfoSection 
            data={formData}
            onChange={handleChange}
            errors={errors}
          />

          {/* Lead Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Source" error={errors.source}>
              <input
                type="text"
                name="source"
                value={formData.source}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors"
                placeholder="e.g., Website, Referral, Advertisement"
              />
            </FormField>

            <FormField label="Status" error={errors.status}>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors"
              >
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="unqualified">Unqualified</option>
              </select>
            </FormField>
          </div>

          {/* Sales Person Assignment */}
          <SalesPersonSection
            value={formData.assigned_sales_person_id}
            onChange={handleChange}
            error={errors.assigned_sales_person_id}
          />

          {/* Notes */}
          <FormField label="Notes" error={errors.notes}>
            <StandardTextarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={4}
              placeholder="Add any additional notes about this lead..."
              error={errors.notes}
            />
          </FormField>
        </FormSection>

        {/* Form Actions */}
        <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-200">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center px-4 py-2 border border-slate-300 text-slate-700 bg-white rounded-lg hover:bg-slate-50 transition-colors"
          >
            <X className="w-4 h-4 mr-2" />
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Saving..." : isEditing ? "Update Lead" : "Create Lead"}
          </button>
        </div>
      </form>
    </div>
  );
}
