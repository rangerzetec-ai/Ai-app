import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Calendar as CalendarIcon, Filter, Users, Clock } from "lucide-react";
import Layout from "@/react-app/components/Layout";
import CalendarScheduler from "@/react-app/components/CalendarScheduler";
import { Appointment, Lead } from "@/shared/types";
import { useIsMobile } from "@/react-app/hooks/useIsMobile";

export default function Calendar() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [appointmentsRes, leadsRes] = await Promise.all([
          fetch("/api/appointments"),
          fetch("/api/leads")
        ]);

        if (appointmentsRes.ok) {
          const appointmentsData = await appointmentsRes.json();
          const appointments = Array.isArray(appointmentsData) ? appointmentsData : (appointmentsData.data || []);
          setAppointments(appointments);
        }

        if (leadsRes.ok) {
          const leadsData = await leadsRes.json();
          const leads = Array.isArray(leadsData) ? leadsData : (leadsData.data || []);
          setLeads(leads);
        }
      } catch (error) {
        console.error("Failed to fetch calendar data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  

  const handleDateSelect = (date: Date) => {
    // Navigate to new appointment page with pre-selected date
    const isoDate = date.toISOString().slice(0, 16);
    navigate(`/appointments/new?date=${isoDate}`);
  };

  const filteredAppointments = appointments.filter(apt => {
    if (filterStatus !== "all" && apt.status !== filterStatus) return false;
    if (filterType !== "all" && apt.appointment_type !== filterType) return false;
    return true;
  });

  const filteredLeads = leads.filter(lead => {
    if (filterStatus !== "all") {
      if (filterStatus === "active" && !["new", "contacted", "qualified"].includes(lead.status)) return false;
      if (filterStatus === "new" && lead.status !== "new") return false;
    }
    return true;
  });

  const getStats = () => {
    const today = new Date();
    const thisWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    const upcomingAppointments = appointments.filter(apt => {
      const aptDate = new Date(apt.appointment_date);
      return aptDate > today && aptDate <= thisWeek && !["cancelled", "completed"].includes(apt.status);
    });

    const todayAppointments = appointments.filter(apt => {
      const aptDate = new Date(apt.appointment_date);
      return aptDate.toDateString() === today.toDateString() && !["cancelled", "completed"].includes(apt.status);
    });

    const activeLeads = leads.filter(lead => ["new", "contacted"].includes(lead.status));

    return {
      today: todayAppointments.length,
      upcoming: upcomingAppointments.length,
      activeLeads: activeLeads.length
    };
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      </Layout>
    );
  }

  const stats = getStats();

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className={`font-bold text-slate-900 ${isMobile ? 'text-xl' : 'text-3xl'}`}>
              Calendar
            </h1>
            {!isMobile && (
              <p className="text-slate-600 mt-1">Schedule and manage appointments and follow-ups</p>
            )}
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => navigate('/appointments/new')}
              className={`inline-flex items-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 ${
                isMobile ? 'px-3 py-2 text-sm' : 'px-4 py-2'
              }`}
            >
              <Plus className={`mr-2 ${isMobile ? 'w-4 h-4' : 'w-4 h-4'}`} />
              {isMobile ? 'New' : 'New Appointment'}
            </button>
            {!isMobile && (
              <button
                onClick={() => navigate('/appointments/new')}
                className="inline-flex items-center px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors"
              >
                <CalendarIcon className="w-4 h-4 mr-2" />
                Quick Schedule
              </button>
            )}
          </div>
        </div>

        {/* Stats Cards */}
        <div className={`grid gap-4 ${isMobile ? 'grid-cols-3' : 'grid-cols-3 md:grid-cols-3'}`}>
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">Today</p>
                <p className="text-2xl font-bold text-blue-900">{stats.today}</p>
              </div>
              <Clock className="w-6 h-6 text-blue-500" />
            </div>
          </div>
          
          <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-indigo-600">This Week</p>
                <p className="text-2xl font-bold text-indigo-900">{stats.upcoming}</p>
              </div>
              <CalendarIcon className="w-6 h-6 text-indigo-500" />
            </div>
          </div>
          
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">Active Leads</p>
                <p className="text-2xl font-bold text-purple-900">{stats.activeLeads}</p>
              </div>
              <Users className="w-6 h-6 text-purple-500" />
            </div>
          </div>
        </div>

        {/* Filters */}
        {!isMobile && (
          <div className="flex items-center space-x-4 p-4 bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-xl">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-slate-400" />
              <span className="text-sm font-medium text-slate-700">Filters:</span>
            </div>
            
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm"
            >
              <option value="all">All Statuses</option>
              <option value="scheduled">Scheduled</option>
              <option value="confirmed">Confirmed</option>
              <option value="active">Active Leads</option>
              <option value="new">New Leads</option>
            </select>

            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm"
            >
              <option value="all">All Types</option>
              <option value="consultation">Consultation</option>
              <option value="estimate">Estimate</option>
              <option value="inspection">Inspection</option>
              <option value="follow_up">Follow Up</option>
            </select>

            <div className="flex items-center space-x-4 text-sm text-slate-600">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded"></div>
                <span>Scheduled</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded"></div>
                <span>Confirmed</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-purple-500 rounded"></div>
                <span>Follow-ups</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-gray-500 rounded"></div>
                <span>Completed</span>
              </div>
            </div>
          </div>
        )}

        {/* Calendar */}
        <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl p-6">
          <CalendarScheduler
            appointments={filteredAppointments}
            leads={filteredLeads}
            onDateSelect={handleDateSelect}
            height={isMobile ? 400 : 600}
            showToolbar={!isMobile}
          />
        </div>

        {/* Mobile Legend */}
        {isMobile && (
          <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-xl p-4">
            <h3 className="text-sm font-medium text-slate-900 mb-3">Legend</h3>
            <div className="grid grid-cols-2 gap-3 text-xs text-slate-600">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded"></div>
                <span>Scheduled</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded"></div>
                <span>Confirmed</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-purple-500 rounded"></div>
                <span>Follow-ups</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-gray-500 rounded"></div>
                <span>Completed</span>
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className={`grid gap-4 ${isMobile ? 'grid-cols-1 pb-24' : 'grid-cols-2 md:grid-cols-4'}`}>
          <button
            onClick={() => navigate('/appointments/new')}
            className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl hover:from-indigo-100 hover:to-purple-100 transition-all duration-200 text-left"
          >
            <CalendarIcon className="w-6 h-6 text-indigo-600 mb-2" />
            <h3 className="font-medium text-slate-900">Schedule Appointment</h3>
            <p className="text-sm text-slate-600">Book a new consultation or estimate</p>
          </button>

          <button
            onClick={() => navigate('/leads/new')}
            className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-xl hover:from-purple-100 hover:to-pink-100 transition-all duration-200 text-left"
          >
            <Users className="w-6 h-6 text-purple-600 mb-2" />
            <h3 className="font-medium text-slate-900">Add New Lead</h3>
            <p className="text-sm text-slate-600">Create a new lead and schedule follow-up</p>
          </button>

          <button
            onClick={() => navigate('/appointments')}
            className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl hover:from-blue-100 hover:to-indigo-100 transition-all duration-200 text-left"
          >
            <Clock className="w-6 h-6 text-blue-600 mb-2" />
            <h3 className="font-medium text-slate-900">View All Appointments</h3>
            <p className="text-sm text-slate-600">Manage your appointment schedule</p>
          </button>

          <button
            onClick={() => navigate('/leads')}
            className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl hover:from-green-100 hover:to-emerald-100 transition-all duration-200 text-left"
          >
            <Filter className="w-6 h-6 text-green-600 mb-2" />
            <h3 className="font-medium text-slate-900">Manage Leads</h3>
            <p className="text-sm text-slate-600">Review and qualify your leads</p>
          </button>
        </div>
      </div>
    </Layout>
  );
}
