
-- Revert to the old hash (though this is just for completeness)
UPDATE password_users 
SET password_hash = '$2a$10$N9qo8uLOickgx2ZMRZoMye5IFrCdX42j2oS5bRxRlIgJGpT3dC2oG' 
WHERE email = 'RangerZetec@gmail.com';
