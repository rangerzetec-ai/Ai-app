
DELETE FROM password_users WHERE email = 'admin@pierpro.com';
