import { FormField, StandardInput } from "./FormField";

interface AddressInfoSectionProps {
  data: {
    address_line1: string;
    address_line2: string;
    city: string;
    state: string;
    zip_code: string;
  };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  errors: Record<string, string>;
  showAllFields?: boolean;
}

export default function AddressInfoSection({ 
  data, 
  onChange, 
  errors, 
  showAllFields = true 
}: AddressInfoSectionProps) {
  if (!showAllFields) {
    return null;
  }

  return (
    <div className="space-y-4">
      <FormField label="Address Line 1" error={errors.address_line1}>
        <StandardInput
          name="address_line1"
          value={data.address_line1}
          onChange={onChange}
          placeholder="Enter street address"
          error={errors.address_line1}
        />
      </FormField>

      <FormField label="Address Line 2" error={errors.address_line2}>
        <StandardInput
          name="address_line2"
          value={data.address_line2}
          onChange={onChange}
          placeholder="Apt, suite, etc."
          error={errors.address_line2}
        />
      </FormField>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <FormField label="City" error={errors.city}>
          <StandardInput
            name="city"
            value={data.city}
            onChange={onChange}
            placeholder="Enter city"
            error={errors.city}
          />
        </FormField>

        <FormField label="State" error={errors.state}>
          <StandardInput
            name="state"
            value={data.state}
            onChange={onChange}
            placeholder="State"
            error={errors.state}
          />
        </FormField>

        <FormField label="Zip Code" error={errors.zip_code}>
          <StandardInput
            name="zip_code"
            value={data.zip_code}
            onChange={onChange}
            placeholder="Zip code"
            error={errors.zip_code}
          />
        </FormField>
      </div>
    </div>
  );
}
