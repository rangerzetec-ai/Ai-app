import { memo, useMemo, Suspense, lazy } from 'react';
import { Users, Calendar, TrendingUp, DollarSign, AlertCircle, ArrowUpRight, Loader2 } from 'lucide-react';
import { useDashboardData } from '../hooks/useTenant';

// Lazy load heavy components
const ReportsModule = lazy(() => import('./ReportsModule'));

interface DashboardMetrics {
  total_leads: number;
  active_leads: number;
  converted_leads: number;
  total_appointments: number;
  completed_appointments: number;
  total_projects: number;
  active_projects: number;
  completed_projects: number;
  total_revenue: number;
  total_expenses: number;
  profit_margin: number;
  average_project_value: number;
  tenant_info?: {
    id: number;
    name: string;
    subscription_plan: string;
  };
}

interface DashboardData {
  metrics: DashboardMetrics;
  recentLeads: any[];
  upcomingAppointments: any[];
}

const MetricCard = memo(({ 
  title, 
  value, 
  icon: Icon, 
  change, 
  changeType = 'positive',
  color = 'blue' 
}: {
  title: string;
  value: string | number;
  icon: any;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  color?: 'blue' | 'green' | 'purple' | 'orange';
}) => {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600', 
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600'
  };

  const changeColorClasses = {
    positive: 'text-green-600 bg-green-50',
    negative: 'text-red-600 bg-red-50',
    neutral: 'text-slate-600 bg-slate-50'
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600">{title}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
          {change && (
            <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-2 ${changeColorClasses[changeType]}`}>
              <ArrowUpRight className="w-3 h-3 mr-1" />
              {change}
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
});

MetricCard.displayName = 'MetricCard';

const QuickStats = memo(({ metrics }: { metrics: DashboardMetrics }) => {
  const statsData = useMemo(() => [
    {
      title: 'Total Leads',
      value: metrics.total_leads || 0,
      icon: Users,
      change: `${metrics.active_leads || 0} active`,
      color: 'blue' as const
    },
    {
      title: 'Appointments',
      value: metrics.total_appointments || 0,
      icon: Calendar,
      change: `${metrics.completed_appointments || 0} completed`,
      color: 'green' as const
    },
    {
      title: 'Active Projects',
      value: metrics.active_projects || 0,
      icon: TrendingUp,
      change: `${metrics.completed_projects || 0} completed`,
      color: 'purple' as const
    },
    {
      title: 'Total Revenue',
      value: `$${(metrics.total_revenue || 0).toLocaleString()}`,
      icon: DollarSign,
      change: `${(metrics.profit_margin || 0).toFixed(1)}% margin`,
      changeType: (metrics.profit_margin || 0) > 0 ? 'positive' as const : 'negative' as const,
      color: 'green' as const
    }
  ], [metrics]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      {statsData.map((stat, index) => (
        <MetricCard key={index} {...stat} />
      ))}
    </div>
  );
});

QuickStats.displayName = 'QuickStats';

const TenantInfo = memo(({ tenant }: { tenant?: DashboardMetrics['tenant_info'] }) => (
  <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl p-6 shadow-lg">
    <div className="flex items-center justify-between">
      <div>
        <h2 className="text-2xl font-bold">{tenant?.name || 'Organization'}</h2>
        <p className="text-blue-100 mt-1">
          {tenant?.subscription_plan ? 
            tenant.subscription_plan.charAt(0).toUpperCase() + tenant.subscription_plan.slice(1) + ' Plan' :
            'Basic Plan'
          }
        </p>
      </div>
      <div className="text-right">
        <div className="text-xs text-blue-100">Tenant ID</div>
        <div className="font-mono text-sm">{tenant?.id || 'N/A'}</div>
      </div>
    </div>
  </div>
));

TenantInfo.displayName = 'TenantInfo';

const ErrorFallback = memo(({ error, retry }: { error: string | Error; retry?: () => void }) => (
  <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
    <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-4" />
    <h3 className="text-lg font-semibold text-red-900 mb-2">Dashboard Error</h3>
    <p className="text-red-700 mb-4">{typeof error === 'string' ? error : error.message}</p>
    {retry && (
      <button
        onClick={retry}
        className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
      >
        Try Again
      </button>
    )}
  </div>
));

ErrorFallback.displayName = 'ErrorFallback';

const LoadingCard = memo(() => (
  <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100 animate-pulse">
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <div className="h-4 bg-slate-200 rounded w-1/3 mb-3"></div>
        <div className="h-8 bg-slate-200 rounded w-1/2 mb-2"></div>
        <div className="h-6 bg-slate-200 rounded w-1/4"></div>
      </div>
      <div className="w-12 h-12 bg-slate-200 rounded-lg"></div>
    </div>
  </div>
));

LoadingCard.displayName = 'LoadingCard';

export default memo(function PerformanceOptimizedDashboard() {
  // Use the actual dashboard data hook
  const { data: dashboardData, loading, error, refetch: refresh } = useDashboardData();

  if (loading && !dashboardData) {
    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-slate-200 to-slate-300 text-transparent rounded-xl p-6 shadow-lg animate-pulse">
          <div className="h-8 bg-slate-300 rounded w-1/3 mb-2"></div>
          <div className="h-4 bg-slate-300 rounded w-1/4"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <LoadingCard key={i} />
          ))}
        </div>
        
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          <span className="ml-2 text-slate-600">Loading dashboard data...</span>
        </div>
      </div>
    );
  }

  if (error && !dashboardData) {
    return <ErrorFallback error={error} retry={refresh} />;
  }

  // Type-safe data access with defaults
  const typedData = dashboardData as DashboardData | null;
  const metrics = typedData?.metrics || {
    total_leads: 0,
    active_leads: 0,
    converted_leads: 0,
    total_appointments: 0,
    completed_appointments: 0,
    total_projects: 0,
    active_projects: 0,
    completed_projects: 0,
    total_revenue: 0,
    total_expenses: 0,
    profit_margin: 0,
    average_project_value: 0
  };
  const recentLeads = typedData?.recentLeads || [];
  const upcomingAppointments = typedData?.upcomingAppointments || [];

  return (
    <div className="space-y-6">
      {/* Tenant Information */}
      <TenantInfo tenant={metrics.tenant_info} />

      {/* Key Metrics */}
      <QuickStats metrics={metrics} />

      {/* Activity Overview */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Recent Leads */}
        <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">Recent Leads</h3>
            <span className="text-sm text-slate-500">{recentLeads.length} items</span>
          </div>
          
          {recentLeads.length > 0 ? (
            <div className="space-y-3">
              {recentLeads.slice(0, 5).map((lead: any) => (
                <div key={lead.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div>
                    <div className="font-medium text-slate-900">
                      {lead.first_name} {lead.last_name}
                    </div>
                    <div className="text-sm text-slate-600">
                      {lead.source && `${lead.source} • `}
                      {new Date(lead.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    lead.status === 'qualified' ? 'bg-green-100 text-green-800' :
                    lead.status === 'contacted' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {lead.status}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              No recent leads
            </div>
          )}
        </div>

        {/* Upcoming Appointments */}
        <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">Upcoming Appointments</h3>
            <span className="text-sm text-slate-500">{upcomingAppointments.length} scheduled</span>
          </div>
          
          {upcomingAppointments.length > 0 ? (
            <div className="space-y-3">
              {upcomingAppointments.slice(0, 5).map((appointment: any) => (
                <div key={appointment.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div>
                    <div className="font-medium text-slate-900">
                      {appointment.lead_name || 'Unknown'}
                    </div>
                    <div className="text-sm text-slate-600">
                      {new Date(appointment.appointment_date).toLocaleDateString()} • 
                      {appointment.appointment_type}
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                    appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {appointment.status}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              No upcoming appointments
            </div>
          )}
        </div>
      </div>

      {/* Performance Monitoring */}
      {(loading || metrics.total_leads > 1000 || metrics.total_appointments > 500) && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center">
            <TrendingUp className="w-5 h-5 text-blue-600 mr-2" />
            <div>
              <div className="font-medium text-blue-900">Performance Optimized</div>
              <div className="text-sm text-blue-700">
                {loading && "Server-side caching active • "}
                {metrics.total_leads > 1000 && "Large dataset detected • "}
                Optimized for {metrics.tenant_info?.subscription_plan || 'basic'} plan
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lazy loaded components for better initial load performance */}
      <Suspense fallback={
        <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-blue-600 mr-2" />
            <span className="text-slate-600">Loading additional modules...</span>
          </div>
        </div>
      }>
        {metrics.total_revenue > 0 && (
          <ReportsModule />
        )}
      </Suspense>
    </div>
  );
});
