import React, { useState, useEffect, useCallback } from "react";
import { Calendar, momentLocalizer, Views, View } from "react-big-calendar";
import moment from "moment";
import { Link } from "react-router-dom";
import { Plus, Calendar as CalendarIcon, Clock, MapPin, User, Phone, Mail, Edit, Eye } from "lucide-react";
import { Lead } from "@/shared/types";
import "react-big-calendar/lib/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  resource: {
    type: 'appointment' | 'lead_followup';
    data: any;
    status: string;
  };
}

interface CalendarSchedulerProps {
  appointments?: any[];
  leads?: Lead[];
  onEventSelect?: (event: CalendarEvent) => void;
  onDateSelect?: (date: Date) => void;
  showToolbar?: boolean;
  height?: number;
}

export default function CalendarScheduler({
  appointments = [],
  leads = [],
  onEventSelect,
  onDateSelect,
  showToolbar = true,
  height = 600
}: CalendarSchedulerProps) {
  const [view, setView] = useState<View>(Views.MONTH);
  const [date, setDate] = useState(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [showEventModal, setShowEventModal] = useState(false);

  useEffect(() => {
    const appointmentEvents: CalendarEvent[] = appointments.map(apt => {
      const startDate = new Date(apt.appointment_date);
      const endDate = new Date(startDate.getTime() + (apt.duration_minutes || 60) * 60000);
      
      return {
        id: `appointment-${apt.id}`,
        title: `${apt.appointment_type} - ${apt.location_address || 'TBD'}`,
        start: startDate,
        end: endDate,
        resource: {
          type: 'appointment',
          data: apt,
          status: apt.status
        }
      };
    });

    const leadEvents: CalendarEvent[] = leads
      .filter(lead => lead.status === 'new' || lead.status === 'contacted')
      .map(lead => {
        const followUpDate = new Date();
        if (lead.status === 'new') {
          followUpDate.setDate(followUpDate.getDate() + 1);
        } else {
          followUpDate.setDate(followUpDate.getDate() + 3);
        }
        
        const endDate = new Date(followUpDate.getTime() + 30 * 60000);
        
        return {
          id: `lead-${lead.id}`,
          title: `Follow-up: ${lead.first_name} ${lead.last_name}`,
          start: followUpDate,
          end: endDate,
          resource: {
            type: 'lead_followup',
            data: lead,
            status: lead.status
          }
        };
      });

    setEvents([...appointmentEvents, ...leadEvents]);
  }, [appointments, leads]);

  // Note: Drag and drop functionality requires react-big-calendar with DnD addon
  // For now, we'll handle updates through the event modal

  const handleSelectEvent = useCallback((event: CalendarEvent) => {
    setSelectedEvent(event);
    setShowEventModal(true);
    onEventSelect?.(event);
  }, [onEventSelect]);

  const handleSelectSlot = useCallback(({ start }: { start: Date }) => {
    onDateSelect?.(start);
  }, [onDateSelect]);

  const eventStyleGetter = useCallback((event: CalendarEvent) => {
    const { type, status } = event.resource;
    
    let backgroundColor = '#3174ad';
    let borderColor = '#3174ad';
    
    if (type === 'appointment') {
      switch (status) {
        case 'scheduled':
          backgroundColor = '#3b82f6';
          borderColor = '#2563eb';
          break;
        case 'confirmed':
          backgroundColor = '#10b981';
          borderColor = '#059669';
          break;
        case 'completed':
          backgroundColor = '#6b7280';
          borderColor = '#4b5563';
          break;
        case 'cancelled':
          backgroundColor = '#ef4444';
          borderColor = '#dc2626';
          break;
        case 'no_show':
          backgroundColor = '#f59e0b';
          borderColor = '#d97706';
          break;
      }
    } else if (type === 'lead_followup') {
      backgroundColor = '#8b5cf6';
      borderColor = '#7c3aed';
    }

    return {
      style: {
        backgroundColor,
        borderColor,
        color: 'white',
        border: `2px solid ${borderColor}`,
        borderRadius: '4px',
        fontSize: '12px',
        padding: '2px 4px'
      }
    };
  }, []);

  const CustomToolbar = ({ label, onNavigate, onView }: any) => (
    <div className="flex items-center justify-between mb-4 p-4 bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-xl">
      <div className="flex items-center space-x-4">
        <button
          onClick={() => onNavigate('PREV')}
          className="px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
        >
          ←
        </button>
        <h2 className="text-xl font-semibold text-slate-900">{label}</h2>
        <button
          onClick={() => onNavigate('NEXT')}
          className="px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
        >
          →
        </button>
        <button
          onClick={() => onNavigate('TODAY')}
          className="px-3 py-2 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors"
        >
          Today
        </button>
      </div>
      
      <div className="flex items-center space-x-2">
        {[
          { key: Views.MONTH, label: 'Month' },
          { key: Views.WEEK, label: 'Week' },
          { key: Views.DAY, label: 'Day' },
          { key: Views.AGENDA, label: 'Agenda' }
        ].map(({ key, label }) => (
          <button
            key={key}
            onClick={() => onView(key)}
            className={`px-3 py-2 rounded-lg transition-colors ${
              view === key
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );

  const EventModal = () => {
    if (!selectedEvent) return null;

    const { type, data, status } = selectedEvent.resource;
    const isAppointment = type === 'appointment';
    const appointment = isAppointment ? data : null;
    const lead = !isAppointment ? data as Lead : null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-6 max-w-md w-full">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">
              {isAppointment ? 'Appointment Details' : 'Lead Follow-up'}
            </h3>
            <button
              onClick={() => setShowEventModal(false)}
              className="text-slate-400 hover:text-slate-600"
            >
              ✕
            </button>
          </div>

          <div className="space-y-4">
            {isAppointment && appointment ? (
              <>
                <div className="flex items-center space-x-3">
                  <CalendarIcon className="w-5 h-5 text-indigo-600" />
                  <div>
                    <p className="font-medium text-slate-900">
                      {appointment.appointment_type.replace('_', ' ')}
                    </p>
                    <p className="text-sm text-slate-600">
                      {moment(appointment.appointment_date).format('MMMM Do, YYYY at h:mm A')}
                    </p>
                  </div>
                </div>

                {appointment.location_address && (
                  <div className="flex items-start space-x-3">
                    <MapPin className="w-5 h-5 text-slate-400 mt-0.5" />
                    <p className="text-slate-600">{appointment.location_address}</p>
                  </div>
                )}

                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-slate-400" />
                  <p className="text-slate-600">{appointment.duration_minutes} minutes</p>
                </div>

                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    status === 'scheduled' ? 'bg-blue-500' :
                    status === 'confirmed' ? 'bg-green-500' :
                    status === 'completed' ? 'bg-gray-500' :
                    status === 'cancelled' ? 'bg-red-500' : 'bg-yellow-500'
                  }`} />
                  <p className="text-slate-600 capitalize">{status.replace('_', ' ')}</p>
                </div>

                <div className="flex space-x-3 pt-4">
                  <Link
                    to={`/appointments/${appointment.id}`}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                    onClick={() => setShowEventModal(false)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View
                  </Link>
                  <Link
                    to={`/appointments/${appointment.id}/edit`}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
                    onClick={() => setShowEventModal(false)}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Link>
                </div>
              </>
            ) : lead ? (
              <>
                <div className="flex items-center space-x-3">
                  <User className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="font-medium text-slate-900">
                      {lead.first_name} {lead.last_name}
                    </p>
                    <p className="text-sm text-slate-600 capitalize">{status} lead</p>
                  </div>
                </div>

                {lead.email && (
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-slate-400" />
                    <a href={`mailto:${lead.email}`} className="text-indigo-600 hover:text-indigo-700">
                      {lead.email}
                    </a>
                  </div>
                )}

                {lead.phone && (
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-slate-400" />
                    <a href={`tel:${lead.phone}`} className="text-indigo-600 hover:text-indigo-700">
                      {lead.phone}
                    </a>
                  </div>
                )}

                <div className="flex space-x-3 pt-4">
                  <Link
                    to={`/leads/${lead.id}`}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    onClick={() => setShowEventModal(false)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View Lead
                  </Link>
                  <Link
                    to={`/leads/${lead.id}/appointments/new`}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                    onClick={() => setShowEventModal(false)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Schedule
                  </Link>
                </div>
              </>
            ) : null}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {React.createElement(Calendar as any, {
        localizer,
        events,
        startAccessor: "start",
        endAccessor: "end",
        style: { height },
        view,
        onView: setView,
        date,
        onNavigate: setDate,
        onSelectEvent: handleSelectEvent,
        onSelectSlot: handleSelectSlot,
        eventPropGetter: eventStyleGetter,
        selectable: true,
        step: 15,
        timeslots: 4,
        min: new Date(2024, 0, 1, 7, 0),
        max: new Date(2024, 0, 1, 19, 0),
        ...(showToolbar ? { components: { toolbar: CustomToolbar } } : {})
      })}

      {showEventModal && <EventModal />}
    </div>
  );
}
