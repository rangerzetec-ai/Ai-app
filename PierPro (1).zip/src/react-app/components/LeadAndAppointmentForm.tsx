import { useState } from "react";
import { Save, X, Calendar, UserPlus } from "lucide-react";
import { CreateLeadWithAppointment } from "@/shared/types";
import AddressAutocomplete from "./AddressAutocomplete";
import { FormSection, FormField, StandardInput, StandardTextarea, StandardSelect } from "./shared/FormField";
import ContactInfoSection from "./shared/ContactInfoSection";
import AddressInfoSection from "./shared/AddressInfoSection";
import SalesPersonSection from "./shared/SalesPersonSection";
import FoundationInfoSection from "./shared/FoundationInfoSection";

interface LeadAndAppointmentFormProps {
  onSubmit: (data: CreateLeadWithAppointment) => Promise<void>;
  onCancel: () => void;
  preSelectedDate?: string;
}

export default function LeadAndAppointmentForm({ onSubmit, onCancel, preSelectedDate }: LeadAndAppointmentFormProps) {
  const [leadData, setLeadData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    address_line1: "",
    address_line2: "",
    city: "",
    state: "",
    zip_code: "",
    notes: "",
    source: "",
    status: "new" as const,
    assigned_sales_person_id: "",
  });

  const [appointmentData, setAppointmentData] = useState({
    appointment_date: preSelectedDate || "",
    appointment_type: "consultation" as const,
    status: "scheduled" as const,
    notes: "",
    location_address: "",
    duration_minutes: 60,
    technician_notes: "",
    assigned_sales_person_id: "",
    foundation_type: "",
    pier_type: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const handleLeadChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setLeadData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleAppointmentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setAppointmentData(prev => ({ 
      ...prev, 
      [name]: type === "number" ? parseInt(value) || 0 : value 
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    // Lead validation
    if (!leadData.first_name.trim()) {
      newErrors.first_name = "First name is required";
    }
    
    if (!leadData.last_name.trim()) {
      newErrors.last_name = "Last name is required";
    }
    
    if (leadData.email && !/\S+@\S+\.\S+/.test(leadData.email)) {
      newErrors.email = "Invalid email format";
    }
    
    // Appointment validation
    if (!appointmentData.appointment_date) {
      newErrors.appointment_date = "Appointment date is required";
    } else {
      const appointmentDate = new Date(appointmentData.appointment_date);
      const now = new Date();
      if (appointmentDate < now) {
        newErrors.appointment_date = "Appointment date cannot be in the past";
      }
    }
    
    if (!appointmentData.location_address) {
      newErrors.location_address = "Property address is required";
    }
    
    if (appointmentData.duration_minutes <= 0) {
      newErrors.duration_minutes = "Duration must be greater than 0";
    }
    
    if (appointmentData.foundation_type === "pier_and_beam" && !appointmentData.pier_type) {
      newErrors.pier_type = "Please select the pier type for pier and beam foundations";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setSaving(true);
    try {
      const submitData: CreateLeadWithAppointment = {
        lead: {
          ...leadData,
          assigned_sales_person_id: leadData.assigned_sales_person_id ? parseInt(leadData.assigned_sales_person_id.toString()) : undefined,
        },
        appointment: {
          ...appointmentData,
          appointment_date: new Date(appointmentData.appointment_date).toISOString(),
          assigned_sales_person_id: appointmentData.assigned_sales_person_id ? parseInt(appointmentData.assigned_sales_person_id.toString()) : undefined,
          foundation_type: (appointmentData.foundation_type as "slab" | "pier_and_beam") || undefined,
          pier_type: (appointmentData.pier_type as "poured" | "blocks" | "posts") || undefined,
        }
      };
      
      await onSubmit(submitData);
    } catch (error) {
      console.error("Failed to save lead and appointment:", error);
      setErrors({ general: "Failed to save lead and appointment. Please try again." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl p-6">
      <form onSubmit={handleSubmit} className="space-y-8">
        {errors.general && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">{errors.general}</p>
          </div>
        )}

        {/* Lead Information Section */}
        <FormSection title="Lead Information" icon={<UserPlus className="w-5 h-5 text-purple-600" />}>
          {/* Contact Information */}
          <ContactInfoSection 
            data={leadData}
            onChange={handleLeadChange}
            errors={errors}
            required={{ first_name: true, last_name: true }}
          />

          {/* Address Information */}
          <AddressInfoSection 
            data={leadData}
            onChange={handleLeadChange}
            errors={errors}
          />

          {/* Lead Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Source" error={errors.source}>
              <StandardInput
                name="source"
                value={leadData.source}
                onChange={handleLeadChange}
                placeholder="e.g., Website, Referral, Advertisement"
                error={errors.source}
              />
            </FormField>

            <SalesPersonSection
              value={leadData.assigned_sales_person_id}
              onChange={handleLeadChange}
              error={errors.assigned_sales_person_id}
            />
          </div>

          {/* Lead Notes */}
          <FormField label="Lead Notes" error={errors.notes}>
            <StandardTextarea
              name="notes"
              value={leadData.notes}
              onChange={handleLeadChange}
              rows={3}
              placeholder="Add any additional notes about this lead..."
              error={errors.notes}
            />
          </FormField>
        </FormSection>

        {/* Appointment Information Section */}
        <FormSection title="Appointment Details" icon={<Calendar className="w-5 h-5 text-indigo-600" />}>
          {/* Date and Duration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Appointment Date & Time" required error={errors.appointment_date}>
              <StandardInput
                name="appointment_date"
                type="datetime-local"
                value={appointmentData.appointment_date}
                onChange={handleAppointmentChange}
                error={errors.appointment_date}
              />
            </FormField>

            <FormField label="Duration (minutes)" error={errors.duration_minutes}>
              <StandardInput
                name="duration_minutes"
                type="number"
                value={appointmentData.duration_minutes.toString()}
                onChange={handleAppointmentChange}
                min="15"
                step="15"
                error={errors.duration_minutes}
              />
            </FormField>
          </div>

          {/* Type and Sales Person */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Appointment Type" error={errors.appointment_type}>
              <StandardSelect
                name="appointment_type"
                value={appointmentData.appointment_type}
                onChange={handleAppointmentChange}
                error={errors.appointment_type}
              >
                <option value="consultation">Consultation</option>
                <option value="estimate">Estimate</option>
                <option value="inspection">Inspection</option>
                <option value="follow_up">Follow Up</option>
              </StandardSelect>
            </FormField>

            <SalesPersonSection
              value={appointmentData.assigned_sales_person_id}
              onChange={handleAppointmentChange}
              error={errors.assigned_sales_person_id}
              label="Sales Person"
            />
          </div>

          {/* Property Address */}
          <FormField label="Property Address" required error={errors.location_address}>
            <AddressAutocomplete
              value={appointmentData.location_address}
              onChange={(address) => setAppointmentData(prev => ({ ...prev, location_address: address }))}
              placeholder="Start typing property address..."
            />
          </FormField>

          {/* Foundation Information */}
          <FoundationInfoSection
            data={appointmentData}
            onChange={handleAppointmentChange}
            errors={errors}
          />

          {/* Appointment Notes */}
          <FormField label="Appointment Notes" error={errors.notes}>
            <StandardTextarea
              name="notes"
              value={appointmentData.notes}
              onChange={handleAppointmentChange}
              rows={3}
              placeholder="Add any additional notes about this appointment..."
              error={errors.notes}
            />
          </FormField>

          {/* Technician Notes */}
          <FormField label="Technician Notes" error={errors.technician_notes}>
            <StandardTextarea
              name="technician_notes"
              value={appointmentData.technician_notes}
              onChange={handleAppointmentChange}
              rows={3}
              placeholder="Field notes, site conditions, special requirements..."
              error={errors.technician_notes}
            />
          </FormField>
        </FormSection>

        {/* Form Actions */}
        <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-200">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center px-4 py-2 border border-slate-300 text-slate-700 bg-white rounded-lg hover:bg-slate-50 transition-colors"
          >
            <X className="w-4 h-4 mr-2" />
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Creating..." : "Create Lead & Schedule Appointment"}
          </button>
        </div>
      </form>
    </div>
  );
}
