import { Link } from "react-router-dom";
import { Users, TrendingUp, Calendar, UserPlus, Clock, Building2 } from "lucide-react";
import Layout from "@/react-app/components/Layout";
import { useDashboardData, useTenant, useTenantPermissions } from "@/react-app/hooks/useTenant";
import { Lead } from "@/shared/types";

export default function Dashboard() {
  const { currentTenant } = useTenant();
  const { canCreate } = useTenantPermissions();
  const { data: dashboardData, loading, error } = useDashboardData();

  const StatCard = ({ title, value, icon: Icon, color, href }: {
    title: string;
    value: number | string;
    icon: any;
    color: string;
    href?: string;
  }) => {
    const content = (
      <div className={`p-6 bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl hover:shadow-lg hover:shadow-${color}-500/10 transition-all duration-300 transform hover:-translate-y-1`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">{title}</p>
            <p className="text-3xl font-bold text-slate-900 mt-2">{value}</p>
          </div>
          <div className={`p-3 rounded-xl bg-${color}-100`}>
            <Icon className={`w-6 h-6 text-${color}-600`} />
          </div>
        </div>
      </div>
    );

    return href ? <Link to={href}>{content}</Link> : content;
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="text-center py-16">
          <h3 className="text-lg font-medium text-slate-900 mb-2">Error loading dashboard</h3>
          <p className="text-slate-500">{error}</p>
        </div>
      </Layout>
    );
  }

  const metrics = (dashboardData as any)?.metrics || {};
  const recentLeads = (dashboardData as any)?.recentLeads || [];
  const upcomingAppointments = (dashboardData as any)?.upcomingAppointments || [];

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header with Tenant Info */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <Building2 className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
                <p className="text-slate-600">{currentTenant?.name || 'Loading...'} • Foundation Repair CRM</p>
              </div>
            </div>
          </div>
          {canCreate && (
            <Link
              to="/clients/new"
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              New Client
            </Link>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <StatCard
            title="Total Leads"
            value={metrics.total_leads || 0}
            icon={UserPlus}
            color="purple"
            href="/leads"
          />
          <StatCard
            title="Upcoming Appointments"
            value={upcomingAppointments.length}
            icon={Clock}
            color="indigo"
            href="/appointments"
          />
          <StatCard
            title="Total Clients"
            value={metrics.total_clients || 0}
            icon={Users}
            color="blue"
            href="/clients"
          />
          <StatCard
            title="Active Projects"
            value={metrics.active_projects || 0}
            icon={TrendingUp}
            color="green"
            href="/projects"
          />
          <StatCard
            title="This Month"
            value={new Date().toLocaleDateString("en-US", { month: "long" })}
            icon={Calendar}
            color="slate"
          />
        </div>

        {/* Tenant Subscription Info */}
        {currentTenant && (
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-blue-900">
                  {currentTenant.subscription_plan.charAt(0).toUpperCase() + currentTenant.subscription_plan.slice(1)} Plan
                </h3>
                <p className="text-blue-700">
                  Multi-tenant organization: {currentTenant.name}
                </p>
              </div>
              <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {currentTenant.subscription_plan.toUpperCase()}
              </div>
            </div>
          </div>
        )}

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Leads */}
          <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-slate-900">Recent Leads</h2>
              <Link
                to="/leads"
                className="text-purple-600 hover:text-purple-700 text-sm font-medium"
              >
                View all
              </Link>
            </div>
            
            {recentLeads.length > 0 ? (
              <div className="space-y-4">
                {recentLeads.map((lead: Lead) => (
                  <Link
                    key={lead.id}
                    to={`/leads/${lead.id}`}
                    className="flex items-center p-3 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-purple-200 rounded-full flex items-center justify-center">
                      <span className="text-purple-600 font-medium text-sm">
                        {lead.first_name[0]}{lead.last_name[0]}
                      </span>
                    </div>
                    <div className="ml-4 flex-1">
                      <p className="font-medium text-slate-900">
                        {lead.first_name} {lead.last_name}
                      </p>
                      <p className="text-sm text-slate-500">{lead.email || lead.phone}</p>
                    </div>
                    <div className="ml-2">
                      <span className="px-2 py-1 text-xs bg-purple-100 text-purple-700 rounded-full">
                        {lead.status}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <UserPlus className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">No leads yet</p>
                {canCreate && (
                  <Link
                    to="/leads/new"
                    className="text-purple-600 hover:text-purple-700 text-sm font-medium"
                  >
                    Add your first lead
                  </Link>
                )}
              </div>
            )}
          </div>

          {/* Upcoming Appointments / Quick Actions */}
          <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl p-6">
            <h2 className="text-xl font-semibold text-slate-900 mb-6">Upcoming Appointments</h2>
            
            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.slice(0, 5).map((appointment: any) => (
                  <Link
                    key={appointment.id}
                    to={`/appointments/${appointment.id}`}
                    className="flex items-center p-3 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-100 to-indigo-200 rounded-full flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div className="ml-4 flex-1">
                      <p className="font-medium text-slate-900">
                        {appointment.lead_name || 'Unknown'}
                      </p>
                      <p className="text-sm text-slate-500">
                        {new Date(appointment.appointment_date).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="ml-2">
                      <span className="px-2 py-1 text-xs bg-indigo-100 text-indigo-700 rounded-full">
                        {appointment.appointment_type}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">No upcoming appointments</p>
                {canCreate && (
                  <Link
                    to="/appointments/new"
                    className="text-indigo-600 hover:text-indigo-700 text-sm font-medium"
                  >
                    Schedule first appointment
                  </Link>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
