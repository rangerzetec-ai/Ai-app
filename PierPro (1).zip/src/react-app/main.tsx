import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import ErrorBoundary from "./components/ErrorBoundary";
import App from "./App";
import "./index.css";

console.log("Main.tsx loading...");

const container = document.getElementById("root");

if (!container) {
  console.error("Root element not found");
  throw new Error("Root element not found");
}

console.log("Creating React root...");

// Create root with error handling
let root: ReturnType<typeof createRoot>;
try {
  root = createRoot(container);
  console.log("React root created successfully");
} catch (error) {
  console.error("Failed to create React root:", error);
  throw error;
}

console.log("Rendering app...");

root.render(
  <StrictMode>
    <ErrorBoundary>
      <BrowserRouter 
        future={{
          v7_startTransition: true,
          v7_relativeSplatPath: true
        }}
      >
        <App />
      </BrowserRouter>
    </ErrorBoundary>
  </StrictMode>
);

console.log("App rendered successfully");

// Register Service Worker for PWA functionality
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/src/react-app/sw.js')
      .then((registration) => {
        console.log('SW registered: ', registration);
      })
      .catch((registrationError) => {
        console.log('SW registration failed: ', registrationError);
      });
  });
}
