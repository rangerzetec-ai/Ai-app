import { Home, Columns } from "lucide-react";
import { FormField, StandardSelect } from "./FormField";

interface FoundationInfoSectionProps {
  data: {
    foundation_type: string;
    pier_type: string;
  };
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  errors: Record<string, string>;
}

export default function FoundationInfoSection({ data, onChange, errors }: FoundationInfoSectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <FormField 
        label={
          <span className="flex items-center">
            <Home className="w-4 h-4 mr-1" />
            Foundation Type
          </span>
        } 
        error={errors.foundation_type}
      >
        <StandardSelect
          name="foundation_type"
          value={data.foundation_type}
          onChange={onChange}
          error={errors.foundation_type}
        >
          <option value="">Select Foundation Type</option>
          <option value="slab">Slab Foundation</option>
          <option value="pier_and_beam">Pier and Beam Foundation</option>
        </StandardSelect>
      </FormField>

      {data.foundation_type === "pier_and_beam" && (
        <FormField 
          label={
            <span className="flex items-center">
              <Columns className="w-4 h-4 mr-1" />
              Pier Type
            </span>
          } 
          error={errors.pier_type}
        >
          <StandardSelect
            name="pier_type"
            value={data.pier_type}
            onChange={onChange}
            error={errors.pier_type}
          >
            <option value="">Select Pier Type</option>
            <option value="poured">Poured Concrete Piers</option>
            <option value="blocks">Concrete Block Piers</option>
            <option value="posts">Wooden Posts</option>
          </StandardSelect>
        </FormField>
      )}
    </div>
  );
}
