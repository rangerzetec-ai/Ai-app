#!/bin/bash

# Fix file watcher limits that cause ENOSPC errors
echo "🔧 Fixing file watcher limits..."

# Clean problematic cache directories
echo "🧹 Cleaning cache directories..."
rm -rf .vite
rm -rf node_modules/.vite
rm -rf .bun/install/cache
find . -name "*.js.map" -path "*/.bun/*" -delete 2>/dev/null || true
find . -name "*.d.ts" -path "*/.bun/*" -delete 2>/dev/null || true

# Clear any existing file watchers
echo "📊 Current file watcher usage:"
if command -v lsof >/dev/null 2>&1; then
    lsof | grep -E "(inotify|fsevents)" | wc -l || echo "Could not determine file watcher count"
fi

# Increase file watcher limits (Linux/WSL)
if [[ "$OSTYPE" == "linux-gnu"* ]] || [[ "$OSTYPE" == "linux-musl"* ]]; then
    echo "🐧 Detected Linux - increasing inotify limits..."
    
    # Check current limits
    echo "Current fs.inotify.max_user_watches: $(cat /proc/sys/fs/inotify/max_user_watches 2>/dev/null || echo 'unknown')"
    echo "Current fs.inotify.max_user_instances: $(cat /proc/sys/fs/inotify/max_user_instances 2>/dev/null || echo 'unknown')"
    
    # Try to increase limits temporarily
    if command -v sudo >/dev/null 2>&1; then
        echo "⬆️ Attempting to increase file watcher limits..."
        sudo sysctl fs.inotify.max_user_watches=524288 2>/dev/null || echo "⚠️ Could not increase max_user_watches (may need manual intervention)"
        sudo sysctl fs.inotify.max_user_instances=512 2>/dev/null || echo "⚠️ Could not increase max_user_instances (may need manual intervention)"
        
        # Make persistent
        if [ -w /etc/sysctl.conf ] || sudo -n true 2>/dev/null; then
            echo "💾 Making changes persistent..."
            echo "fs.inotify.max_user_watches=524288" | sudo tee -a /etc/sysctl.conf >/dev/null 2>&1 || echo "⚠️ Could not make persistent (may need manual intervention)"
            echo "fs.inotify.max_user_instances=512" | sudo tee -a /etc/sysctl.conf >/dev/null 2>&1 || echo "⚠️ Could not make persistent (may need manual intervention)"
        fi
    else
        echo "⚠️ sudo not available - manual intervention may be required"
        echo "📋 To fix manually, run:"
        echo "   sudo sysctl fs.inotify.max_user_watches=524288"
        echo "   sudo sysctl fs.inotify.max_user_instances=512"
    fi
fi

# macOS specific optimizations
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "🍎 Detected macOS - optimizing for fsevents..."
    
    # Kill any hanging file watchers
    pkill -f "fsevents" 2>/dev/null || true
    
    echo "💡 Consider increasing file descriptor limits:"
    echo "   ulimit -n 4096"
fi

# Windows/WSL2 specific
if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || grep -q microsoft /proc/version 2>/dev/null; then
    echo "🪟 Detected Windows/WSL environment..."
    echo "💡 Consider using WSL2 for better file watching performance"
fi

# Clean npm/yarn/bun caches
echo "🧼 Cleaning package manager caches..."
if command -v npm >/dev/null 2>&1; then
    npm cache clean --force 2>/dev/null || echo "⚠️ Could not clean npm cache"
fi

if command -v yarn >/dev/null 2>&1; then
    yarn cache clean 2>/dev/null || echo "⚠️ Could not clean yarn cache"
fi

if command -v bun >/dev/null 2>&1; then
    bun pm cache clean 2>/dev/null || echo "⚠️ Could not clean bun cache"
fi

# Set environment variables for current session
export CHOKIDAR_USEPOLLING=false
export CHOKIDAR_INTERVAL=100
export NODE_OPTIONS="--max-old-space-size=4096"

echo "✅ File watcher optimization complete!"
echo ""
echo "🚀 You can now run:"
echo "   npm run dev"
echo "   or"
echo "   npm run dev:clean (for a completely fresh start)"
echo ""
echo "💡 If you still encounter issues, try:"
echo "   npm run dev:debug (for detailed logging)"
