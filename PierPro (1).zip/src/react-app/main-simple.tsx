import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import SimpleApp from "./SimpleApp";
import "./index.css";

console.log("🚀 Starting PierPro app...");

const container = document.getElementById("root");

if (!container) {
  console.error("❌ Root element not found!");
  document.body.innerHTML = '<div style="padding: 20px; text-align: center;"><h1>Error: Root element not found</h1></div>';
  throw new Error("Root element not found");
}

console.log("✅ Root element found, creating React root...");

try {
  const root = createRoot(container);
  console.log("✅ React root created, rendering app...");
  
  root.render(
    <StrictMode>
      <SimpleApp />
    </StrictMode>
  );
  
  console.log("✅ App rendered successfully!");
} catch (error) {
  console.error("❌ Failed to render app:", error);
  container.innerHTML = `
    <div style="padding: 20px; text-align: center; color: red;">
      <h1>Failed to load PierPro</h1>
      <p>Error: ${error instanceof Error ? error.message : 'Unknown error'}</p>
      <button onclick="window.location.reload()" style="padding: 10px 20px; margin-top: 10px;">Reload Page</button>
    </div>
  `;
}
