import { memo } from 'react';
import { Users, Calendar, TrendingUp, DollarSign } from 'lucide-react';

interface SimpleDashboardProps {
  metrics?: {
    total_leads?: number;
    active_leads?: number;
    total_appointments?: number;
    completed_appointments?: number;
    active_projects?: number;
    total_revenue?: number;
    profit_margin?: number;
  };
}

const MetricCard = memo(({ 
  title, 
  value, 
  icon: Icon, 
  color = 'blue' 
}: {
  title: string;
  value: string | number;
  icon: any;
  color?: 'blue' | 'green' | 'purple' | 'orange';
}) => {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600', 
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600'
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600">{title}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
});

MetricCard.displayName = 'MetricCard';

export default memo(function SimpleDashboard({ metrics = {} }: SimpleDashboardProps) {
  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <MetricCard
          title="Total Leads"
          value={metrics.total_leads || 0}
          icon={Users}
          color="blue"
        />
        <MetricCard
          title="Appointments"
          value={metrics.total_appointments || 0}
          icon={Calendar}
          color="green"
        />
        <MetricCard
          title="Active Projects"
          value={metrics.active_projects || 0}
          icon={TrendingUp}
          color="purple"
        />
        <MetricCard
          title="Total Revenue"
          value={`$${(metrics.total_revenue || 0).toLocaleString()}`}
          icon={DollarSign}
          color="green"
        />
      </div>
    </div>
  );
});
