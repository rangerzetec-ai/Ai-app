import { Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Clients from "./pages/Clients";
import NewClient from "./pages/NewClient";
import EditClient from "./pages/EditClient";
import ClientDetail from "./pages/ClientDetail";
import Leads from "./pages/Leads";
import NewLead from "./pages/NewLead";
import EditLead from "./pages/EditLead";
import LeadDetail from "./pages/LeadDetail";
import Appointments from "./pages/Appointments";
import NewAppointment from "./pages/NewAppointment";
import EditAppointment from "./pages/EditAppointment";
import AppointmentDetail from "./pages/AppointmentDetail";
import TechnicianView from "./pages/TechnicianView";
import Projects from "./pages/Projects";
import NewProject from "./pages/NewProject";
import EditProject from "./pages/EditProject";
import ProjectDetail from "./pages/ProjectDetail";
import SalesPeople from "./pages/SalesPeople";
import NewSalesPerson from "./pages/NewSalesPerson";
import EditSalesPerson from "./pages/EditSalesPerson";
import SalesPersonDetail from "./pages/SalesPersonDetail";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/dashboard" element={<Dashboard />} />
      
      {/* Client routes */}
      <Route path="/clients" element={<Clients />} />
      <Route path="/clients/new" element={<NewClient />} />
      <Route path="/clients/:id" element={<ClientDetail />} />
      <Route path="/clients/:id/edit" element={<EditClient />} />
      
      {/* Lead routes */}
      <Route path="/leads" element={<Leads />} />
      <Route path="/leads/new" element={<NewLead />} />
      <Route path="/leads/:id" element={<LeadDetail />} />
      <Route path="/leads/:id/edit" element={<EditLead />} />
      
      {/* Appointment routes */}
      <Route path="/appointments" element={<Appointments />} />
      <Route path="/appointments/new" element={<NewAppointment />} />
      <Route path="/appointments/:id" element={<AppointmentDetail />} />
      <Route path="/appointments/:id/edit" element={<EditAppointment />} />
      <Route path="/appointments/:id/technician" element={<TechnicianView />} />
      
      {/* Project routes */}
      <Route path="/projects" element={<Projects />} />
      <Route path="/projects/new" element={<NewProject />} />
      <Route path="/projects/:id" element={<ProjectDetail />} />
      <Route path="/projects/:id/edit" element={<EditProject />} />
      <Route path="/clients/:clientId/projects/new" element={<NewProject />} />
      
      {/* Sales people routes */}
      <Route path="/sales-people" element={<SalesPeople />} />
      <Route path="/sales-people/new" element={<NewSalesPerson />} />
      <Route path="/sales-people/:id" element={<SalesPersonDetail />} />
      <Route path="/sales-people/:id/edit" element={<EditSalesPerson />} />
      
      {/* Reports route */}
      <Route path="/reports" element={<Reports />} />
      
      {/* Settings route */}
      <Route path="/settings" element={<Settings />} />
    </Routes>
  );
}
