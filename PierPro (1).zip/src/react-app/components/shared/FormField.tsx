import { ReactNode } from "react";

interface FormFieldProps {
  label: string | ReactNode;
  required?: boolean;
  error?: string;
  children: ReactNode;
  className?: string;
}

export function FormField({ label, required, error, children, className = "" }: FormFieldProps) {
  return (
    <div className={className}>
      <label className="block text-sm font-medium text-slate-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
      {error && (
        <p className="text-red-600 text-sm mt-1">{error}</p>
      )}
    </div>
  );
}

interface FormSectionProps {
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function FormSection({ title, icon, children, className = "" }: FormSectionProps) {
  return (
    <div className={`space-y-6 ${className}`}>
      <div className="flex items-center space-x-2 pb-2 border-b border-slate-200">
        {icon}
        <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
      </div>
      {children}
    </div>
  );
}

interface StandardInputProps {
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;
  placeholder?: string;
  error?: string;
  min?: string;
  step?: string;
  className?: string;
}

export function StandardInput({ 
  name, 
  value, 
  onChange, 
  type = "text", 
  placeholder, 
  error,
  min,
  step,
  className = ""
}: StandardInputProps) {
  return (
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      min={min}
      step={step}
      className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
        error ? "border-red-300" : "border-slate-200"
      } ${className}`}
      placeholder={placeholder}
    />
  );
}

interface StandardTextareaProps {
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder?: string;
  rows?: number;
  error?: string;
}

export function StandardTextarea({ 
  name, 
  value, 
  onChange, 
  placeholder, 
  rows = 3,
  error
}: StandardTextareaProps) {
  return (
    <textarea
      name={name}
      value={value}
      onChange={onChange}
      rows={rows}
      className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors resize-none ${
        error ? "border-red-300" : "border-slate-200"
      }`}
      placeholder={placeholder}
    />
  );
}

interface StandardSelectProps {
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  children: ReactNode;
  error?: string;
}

export function StandardSelect({ name, value, onChange, children, error }: StandardSelectProps) {
  return (
    <select
      name={name}
      value={value}
      onChange={onChange}
      className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
        error ? "border-red-300" : "border-slate-200"
      }`}
    >
      {children}
    </select>
  );
}
