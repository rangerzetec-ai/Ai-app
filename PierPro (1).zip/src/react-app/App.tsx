import { Routes, Route } from "react-router-dom";
import { AuthProvider as MochaAuthProvider } from "@getmocha/users-service/react";
import { AuthProvider } from "./hooks/useAuth";
import { TenantProvider } from "./hooks/useTenant";
import LoadingFallback from "./components/LoadingFallback";
import Dashboard from "./pages/Dashboard";
import Clients from "./pages/Clients";
import NewClient from "./pages/NewClient";
import EditClient from "./pages/EditClient";
import ClientDetail from "./pages/ClientDetail";
import Leads from "./pages/Leads";
import NewLead from "./pages/NewLead";
import EditLead from "./pages/EditLead";
import LeadDetail from "./pages/LeadDetail";
import Appointments from "./pages/Appointments";
import NewAppointment from "./pages/NewAppointment";
import EditAppointment from "./pages/EditAppointment";
import AppointmentDetail from "./pages/AppointmentDetail";
import TechnicianView from "./pages/TechnicianView";
import Projects from "./pages/Projects";
import NewProject from "./pages/NewProject";
import EditProject from "./pages/EditProject";
import ProjectDetail from "./pages/ProjectDetail";
import SalesPeople from "./pages/SalesPeople";
import NewSalesPerson from "./pages/NewSalesPerson";
import EditSalesPerson from "./pages/EditSalesPerson";
import SalesPersonDetail from "./pages/SalesPersonDetail";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Calendar from "./pages/Calendar";
import Login from "./pages/Login";
import AuthCallback from "./pages/AuthCallback";
import UserManagement from "./pages/UserManagement";
import ProtectedRoute from "./components/ProtectedRoute";

export default function App() {
  console.log("App component rendering...");
  
  return (
    <MochaAuthProvider>
      <AuthProvider>
        <TenantProvider>
          <Suspense fallback={<LoadingFallback message="Loading PierPro..." />}>
            <Routes>
        {/* Public routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/auth/callback" element={<AuthCallback />} />
        
        {/* Protected routes */}
        <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        
        {/* Client routes */}
        <Route path="/clients" element={<ProtectedRoute><Clients /></ProtectedRoute>} />
        <Route path="/clients/new" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><NewClient /></ProtectedRoute>} />
        <Route path="/clients/:id" element={<ProtectedRoute><ClientDetail /></ProtectedRoute>} />
        <Route path="/clients/:id/edit" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><EditClient /></ProtectedRoute>} />
        
        {/* Lead routes */}
        <Route path="/leads" element={<ProtectedRoute><Leads /></ProtectedRoute>} />
        <Route path="/leads/new" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><NewLead /></ProtectedRoute>} />
        <Route path="/leads/:id" element={<ProtectedRoute><LeadDetail /></ProtectedRoute>} />
        <Route path="/leads/:id/edit" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><EditLead /></ProtectedRoute>} />
        
        {/* Appointment routes */}
        <Route path="/appointments" element={<ProtectedRoute><Appointments /></ProtectedRoute>} />
        <Route path="/appointments/new" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><NewAppointment /></ProtectedRoute>} />
        <Route path="/appointments/:id" element={<ProtectedRoute><AppointmentDetail /></ProtectedRoute>} />
        <Route path="/appointments/:id/edit" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><EditAppointment /></ProtectedRoute>} />
        <Route path="/appointments/:id/technician" element={<ProtectedRoute><TechnicianView /></ProtectedRoute>} />
        
        {/* Project routes */}
        <Route path="/projects" element={<ProtectedRoute><Projects /></ProtectedRoute>} />
        <Route path="/projects/new" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><NewProject /></ProtectedRoute>} />
        <Route path="/projects/:id" element={<ProtectedRoute><ProjectDetail /></ProtectedRoute>} />
        <Route path="/projects/:id/edit" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><EditProject /></ProtectedRoute>} />
        <Route path="/clients/:clientId/projects/new" element={<ProtectedRoute requiredRoles={['admin', 'sales_person']}><NewProject /></ProtectedRoute>} />
        
        {/* Sales people routes - Admin only */}
        <Route path="/sales-people" element={<ProtectedRoute requiredRoles={['admin']}><SalesPeople /></ProtectedRoute>} />
        <Route path="/sales-people/new" element={<ProtectedRoute requiredRoles={['admin']}><NewSalesPerson /></ProtectedRoute>} />
        <Route path="/sales-people/:id" element={<ProtectedRoute requiredRoles={['admin']}><SalesPersonDetail /></ProtectedRoute>} />
        <Route path="/sales-people/:id/edit" element={<ProtectedRoute requiredRoles={['admin']}><EditSalesPerson /></ProtectedRoute>} />
        
        {/* Calendar route */}
        <Route path="/calendar" element={<ProtectedRoute><Calendar /></ProtectedRoute>} />
        
        {/* Reports route */}
        <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
        
        {/* Settings route - Admin only */}
        <Route path="/settings" element={<ProtectedRoute requiredRoles={['admin']}><Settings /></ProtectedRoute>} />
        
        {/* User Management route - Admin only */}
        <Route path="/user-management" element={<ProtectedRoute requiredRoles={['admin']}><UserManagement /></ProtectedRoute>} />
      </Routes>
          </Suspense>
        </TenantProvider>
      </AuthProvider>
    </MochaAuthProvider>
  );
}
