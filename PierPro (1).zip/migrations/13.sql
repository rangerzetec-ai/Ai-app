
-- Update the admin user with the correct password hash for 'itsasecret'
UPDATE password_users 
SET password_hash = '$2b$10$ybYTIAwQK9Q3qQTxTVgCl.PHvcMH6mEgZxptuSmLlrR0apxNVg/YK' 
WHERE email = 'RangerZetec@gmail.com';
