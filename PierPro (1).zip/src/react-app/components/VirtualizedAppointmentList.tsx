import { memo, useMemo, useCallback } from 'react';
import { useVirtualization } from '../hooks/useVirtualization';
import { useIsMobile } from '../hooks/useIsMobile';
import AppointmentCard from './AppointmentCard';
import MobileAppointmentCard from './MobileAppointmentCard';
import { Appointment } from '@/shared/types';

interface VirtualizedAppointmentListProps {
  appointments: Appointment[];
  onSelect?: (appointment: Appointment) => void;
  loading?: boolean;
}

const ITEM_HEIGHT = 200; // Approximate height of appointment card
const MOBILE_ITEM_HEIGHT = 160;

const VirtualizedAppointmentList = memo(({ 
  appointments, 
  onSelect, 
  loading = false 
}: VirtualizedAppointmentListProps) => {
  const isMobile = useIsMobile();
  const itemHeight = isMobile ? MOBILE_ITEM_HEIGHT : ITEM_HEIGHT;
  const containerHeight = isMobile ? 400 : 600;

  const {
    visibleItems,
    totalHeight,
    handleScroll,
    startIndex,
    endIndex,
  } = useVirtualization({
    items: appointments,
    itemHeight,
    containerHeight,
    overscan: 3
  });

  const memoizedVisibleItems = useMemo(() => visibleItems, [visibleItems]);

  const renderItem = useCallback((item: Appointment & { index: number; offsetY: number }) => {
    const AppointmentComponent = isMobile ? MobileAppointmentCard : AppointmentCard;
    
    return (
      <div
        key={item.id}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: itemHeight,
          transform: `translateY(${item.offsetY}px)`,
        }}
      >
        <div className="p-2 h-full" onClick={() => onSelect?.(item)}>
          <AppointmentComponent
            appointment={item}
          />
        </div>
      </div>
    );
  }, [isMobile, itemHeight, onSelect]);

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div
            key={i}
            className="bg-white rounded-lg shadow-md p-4 animate-pulse"
            style={{ height: itemHeight - 16 }}
          >
            <div className="space-y-3">
              <div className="h-4 bg-slate-200 rounded w-1/3"></div>
              <div className="h-3 bg-slate-200 rounded w-1/2"></div>
              <div className="h-3 bg-slate-200 rounded w-1/4"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (appointments.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-slate-400 text-lg mb-2">📅</div>
        <p className="text-slate-600">No appointments found</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="text-sm text-slate-600 mb-2">
        Showing {startIndex + 1}-{Math.min(endIndex + 1, appointments.length)} of {appointments.length} appointments
      </div>
      
      <div
        className="relative overflow-auto border border-slate-200 rounded-lg"
        style={{ height: containerHeight }}
        onScroll={handleScroll}
      >
        <div style={{ height: totalHeight, position: 'relative' }}>
          {memoizedVisibleItems.map(renderItem)}
        </div>
      </div>
      
      {appointments.length > 50 && (
        <div className="text-xs text-green-600 bg-green-50 p-2 rounded">
          ⚡ Virtualized rendering active - showing {memoizedVisibleItems.length} of {appointments.length} items for optimal performance
        </div>
      )}
    </div>
  );
});

VirtualizedAppointmentList.displayName = 'VirtualizedAppointmentList';

export default VirtualizedAppointmentList;
