import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { Building2 } from "lucide-react";
import { useIsMobile } from "@/react-app/hooks/useIsMobile";
import { useAuth } from "@getmocha/users-service/react";
import MobileLayout from "./MobileLayout";
import UserMenu from "./UserMenu";

interface LayoutProps {
  children: ReactNode;
}

interface UserWithRole {
  id: string;
  email: string;
  role?: string;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const isMobile = useIsMobile();
  const { user } = useAuth();
  
  const userWithRole = user as UserWithRole;
  const isActive = (path: string) => location.pathname === path;
  
  // Filter navigation based on user role
  const getFilteredNavigation = () => {
    const allNavItems = [
      { path: "/", label: "Dashboard" },
      { path: "/leads", label: "Leads" },
      { path: "/calendar", label: "Calendar" },
      { path: "/clients", label: "Clients" },
      { path: "/projects", label: "Projects" },
      { path: "/sales-people", label: "Sales Team", adminOnly: true },
      { path: "/reports", label: "Reports" },
      { path: "/settings", label: "Settings", adminOnly: true },
    ];
    
    return allNavItems.filter(item => 
      !item.adminOnly || userWithRole?.role === 'admin'
    );
  };
  
  const getNavColorClass = (path: string, isActiveItem: boolean) => {
    if (isActiveItem) {
      switch (path) {
        case "/": return "bg-blue-100 text-blue-700 shadow-sm";
        case "/leads": return "bg-purple-100 text-purple-700 shadow-sm";
        case "/calendar": return "bg-violet-100 text-violet-700 shadow-sm";
        case "/clients": return "bg-blue-100 text-blue-700 shadow-sm";
        case "/projects": return "bg-cyan-100 text-cyan-700 shadow-sm";
        case "/sales-people": return "bg-green-100 text-green-700 shadow-sm";
        case "/reports": return "bg-orange-100 text-orange-700 shadow-sm";
        case "/settings": return "bg-slate-100 text-slate-700 shadow-sm";
        default: return "bg-blue-100 text-blue-700 shadow-sm";
      }
    }
    return "text-slate-600 hover:text-slate-900 hover:bg-slate-100";
  };
  
  // Use mobile layout on mobile devices
  if (isMobile) {
    return <MobileLayout>{children}</MobileLayout>;
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <nav className="bg-white/80 backdrop-blur-md border-b border-slate-200/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-700 bg-clip-text text-transparent">
                  PierPro
                </h1>
              </div>
              <div className="flex space-x-1">
                {getFilteredNavigation().map((navItem) => {
                  const isActiveItem = navItem.path === "/" ? isActive("/") : location.pathname.startsWith(navItem.path);
                  const colorClass = getNavColorClass(navItem.path, isActiveItem);
                  
                  return (
                    <Link
                      key={navItem.path}
                      to={navItem.path}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${colorClass}`}
                    >
                      {navItem.label}
                    </Link>
                  );
                })}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <UserMenu />
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}
