import { useState, useEffect } from "react";
import { Shield, Users, Mail, Calendar, Edit2, Check, X } from "lucide-react";
import Layout from "@/react-app/components/Layout";
import { useAuth } from "@getmocha/users-service/react";

interface UserRole {
  user_id: string;
  role: string;
  created_at: string;
  updated_at: string;
}

interface UserWithRole {
  id: string;
  email: string;
  role?: string;
}

export default function UserManagement() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [newRole, setNewRole] = useState<string>("");

  const userWithRole = user as UserWithRole;

  // Only admins should access this page
  if (userWithRole?.role !== 'admin') {
    return (
      <Layout>
        <div className="text-center py-16">
          <h3 className="text-lg font-medium text-slate-900 mb-2">Access Denied</h3>
          <p className="text-slate-500">You don't have permission to access user management.</p>
        </div>
      </Layout>
    );
  }

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch("/api/users");
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      }
    } catch (error) {
      console.error("Failed to fetch users:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateUserRole = async (userId: string, role: string) => {
    try {
      const response = await fetch(`/api/users/${userId}/role`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ role }),
      });

      if (response.ok) {
        await fetchUsers();
        setEditingUser(null);
        setNewRole("");
      } else {
        console.error("Failed to update user role");
      }
    } catch (error) {
      console.error("Failed to update user role:", error);
    }
  };

  const startEdit = (userId: string, currentRole: string) => {
    setEditingUser(userId);
    setNewRole(currentRole);
  };

  const cancelEdit = () => {
    setEditingUser(null);
    setNewRole("");
  };

  const saveEdit = (userId: string) => {
    if (newRole) {
      updateUserRole(userId, newRole);
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800';
      case 'sales_person':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Admin';
      case 'sales_person':
        return 'Sales Person';
      default:
        return 'User';
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-slate-900">User Management</h1>
            <p className="text-slate-600 mt-1">Manage user roles and permissions</p>
          </div>
        </div>

        {/* Role Permissions Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-blue-900 mb-4">Role Permissions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4">
              <div className="flex items-center mb-2">
                <Shield className="w-5 h-5 text-red-600 mr-2" />
                <span className="font-medium text-red-900">Admin</span>
              </div>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Full access to all features</li>
                <li>• Can create, edit, and delete</li>
                <li>• Manage users and settings</li>
                <li>• Access to sales team management</li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <div className="flex items-center mb-2">
                <Shield className="w-5 h-5 text-blue-600 mr-2" />
                <span className="font-medium text-blue-900">Sales Person</span>
              </div>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Can add leads and clients</li>
                <li>• Can edit appointments</li>
                <li>• Cannot delete anything</li>
                <li>• No admin access</li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <div className="flex items-center mb-2">
                <Shield className="w-5 h-5 text-gray-600 mr-2" />
                <span className="font-medium text-gray-900">User</span>
              </div>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• View-only access</li>
                <li>• Can view all data</li>
                <li>• Cannot add or edit</li>
                <li>• No admin access</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900">System Users</h3>
          </div>
          
          {users.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                      User ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Role
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Created
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {users.map((userRole) => (
                    <tr key={userRole.user_id} className="hover:bg-slate-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Mail className="w-4 h-4 text-slate-400 mr-2" />
                          <span className="text-sm font-medium text-slate-900">
                            {userRole.user_id}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {editingUser === userRole.user_id ? (
                          <select
                            value={newRole}
                            onChange={(e) => setNewRole(e.target.value)}
                            className="block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                          >
                            <option value="user">User</option>
                            <option value="sales_person">Sales Person</option>
                            <option value="admin">Admin</option>
                          </select>
                        ) : (
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRoleBadgeColor(userRole.role)}`}>
                            <Shield className="w-3 h-3 mr-1" />
                            {getRoleDisplayName(userRole.role)}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(userRole.created_at).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {editingUser === userRole.user_id ? (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => saveEdit(userRole.user_id)}
                              className="text-green-600 hover:text-green-900"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={cancelEdit}
                              className="text-red-600 hover:text-red-900"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => startEdit(userRole.user_id, userRole.role)}
                            className="text-blue-600 hover:text-blue-900"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No users found</h3>
              <p className="text-slate-500">Users will appear here after they sign in for the first time.</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
