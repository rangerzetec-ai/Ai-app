import { useState, useEffect } from "react";
import { FormField, StandardSelect } from "./FormField";

interface SalesPersonSectionProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  error?: string;
  name?: string;
  label?: string;
  required?: boolean;
}

export default function SalesPersonSection({ 
  value, 
  onChange, 
  error, 
  name = "assigned_sales_person_id",
  label = "Assigned Sales Person",
  required = false 
}: SalesPersonSectionProps) {
  const [salesPeople, setSalesPeople] = useState<any[]>([]);

  useEffect(() => {
    const fetchSalesPeople = async () => {
      try {
        const response = await fetch("/api/sales-people");
        if (response.ok) {
          const data = await response.json();
          setSalesPeople(data.filter((sp: any) => sp.is_active));
        }
      } catch (error) {
        console.error("Failed to fetch sales people:", error);
      }
    };

    fetchSalesPeople();
  }, []);

  return (
    <FormField label={label} required={required} error={error}>
      <StandardSelect
        name={name}
        value={value}
        onChange={onChange}
        error={error}
      >
        <option value="">Select Sales Person</option>
        {salesPeople.map((salesPerson) => (
          <option key={salesPerson.id} value={salesPerson.id}>
            {salesPerson.first_name} {salesPerson.last_name}
          </option>
        ))}
      </StandardSelect>
    </FormField>
  );
}
