import path from "path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { cloudflare } from "@cloudflare/vite-plugin";
import { mochaPlugins } from "@getmocha/vite-plugins";

export default defineConfig({
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  plugins: [...mochaPlugins(process.env as any), react(), cloudflare()],
  cacheDir: '.vite',
  logLevel: 'warn',
  server: {
    allowedHosts: true,
    watch: {
      ignored: [
        "**/node_modules/**",
        "**/.bun/**",
        "**/dist/**",
        "**/build/**",
        "**/.git/**",
        "**/coverage/**",
        "**/.nyc_output/**",
        "**/tmp/**",
        "**/temp/**",
        "**/.cache/**",
        "**/cache/**",
        "**/logs/**",
        "**/*.log",
        "**/.DS_Store",
        "**/Thumbs.db"
      ],
      usePolling: false,
      interval: 100
    },
  },
  build: {
    chunkSizeWarningLimit: 5000,
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          'ui-vendor': ['lucide-react'],
          'three-vendor': ['three'],
          'three-fiber': ['@react-three/fiber', '@react-three/drei'],
          'charts': ['recharts'],
          'calendar': ['react-big-calendar', 'moment']
        }
      },
      external: (id) => {
        // Exclude problematic modules from bundling
        if (id.includes('node_modules/.bun') || 
            id.includes('.bun/install/cache') ||
            id.includes('rollup/') ||
            id.includes('esbuild/')) {
          return true;
        }
        return false;
      }
    },
    target: 'es2020',
    sourcemap: false,
    minify: 'esbuild',
    cssMinify: true
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  optimizeDeps: {
    exclude: [
      "@cloudflare/workers-types",
      "@cloudflare/vite-plugin",
      "@getmocha/vite-plugins",
      "@cloudflare/unenv",
      "@cloudflare/unenv-preset",
      "unenv",
      "node:*",
      "rollup",
      "esbuild"
    ],
    include: [
      "react",
      "react-dom",
      "react-router-dom",
      "lucide-react",
      "zod",
      "hono"
    ],
    entries: [
      "./src/react-app/main.tsx"
    ],
    esbuildOptions: {
      target: "es2020",
      supported: {
        "top-level-await": false
      },
      keepNames: true,
      minify: false
    },
    force: false
  },
  define: {
    global: "globalThis",
    process: "{}",
    __dirname: JSON.stringify(path.resolve(__dirname)),
  },
  ssr: {
    noExternal: ["three", "@react-three/fiber", "@react-three/drei"]
  }
});
