import { useAuth } from "../hooks/useAuth";
import { Navigate } from "react-router-dom";
import type { UserWithRole } from "../../worker/auth";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[];
  fallback?: React.ReactNode;
}

export default function ProtectedRoute({ 
  children, 
  requiredRoles = [], 
  fallback 
}: ProtectedRouteProps) {
  const { user, isPending } = useAuth();

  // Show loading while checking authentication
  if (isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Check role permissions if required roles are specified
  if (requiredRoles.length > 0) {
    const userWithRole = user as UserWithRole;
    const hasRequiredRole = requiredRoles.includes(userWithRole.role || 'user');
    
    if (!hasRequiredRole) {
      // Show fallback component or redirect
      if (fallback) {
        return <>{fallback}</>;
      }
      
      return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50">
          <div className="max-w-md w-full mx-auto">
            <div className="bg-white/70 backdrop-blur-sm border border-slate-200/60 rounded-3xl p-8 shadow-xl shadow-red-500/10 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-red-600 text-2xl">🔒</span>
              </div>
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Access Denied</h2>
              <p className="text-slate-600 mb-4">
                You don't have permission to access this page.
              </p>
              <p className="text-sm text-slate-500">
                Contact your administrator if you believe this is an error.
              </p>
            </div>
          </div>
        </div>
      );
    }
  }

  return <>{children}</>;
}
