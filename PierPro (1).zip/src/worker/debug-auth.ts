import { Hono } from "hono";
import * as bcrypt from "bcryptjs";

interface Env {
  DB: any;
}

const app = new Hono<{ Bindings: Env }>();

// Debug endpoint to check password users
app.get("/api/debug/password-users", async (c) => {
  try {
    const users = await c.env.DB.prepare("SELECT id, email, name, is_active, created_at FROM password_users").all();
    return c.json({
      count: users.results.length,
      users: users.results
    });
  } catch (error) {
    console.error("Debug error:", error);
    return c.json({ error: "Debug failed" }, 500);
  }
});

// Debug endpoint to test password hashing
app.post("/api/debug/test-password", async (c) => {
  try {
    const { password, hash } = await c.req.json();
    
    if (!password || !hash) {
      return c.json({ error: "Password and hash required" }, 400);
    }
    
    const isValid = await bcrypt.compare(password, hash);
    return c.json({ 
      valid: isValid,
      password_length: password.length,
      hash_length: hash.length
    });
  } catch (error) {
    console.error("Password test error:", error);
    return c.json({ error: "Test failed" }, 500);
  }
});

// Debug endpoint to create test user
app.post("/api/debug/create-test-user", async (c) => {
  try {
    const email = "test@pierpro.com";
    const password = "test123";
    const name = "Test User";
    
    // Check if user exists
    const existingUser = await c.env.DB.prepare("SELECT * FROM password_users WHERE email = ?")
      .bind(email).first();
    
    if (existingUser) {
      return c.json({ message: "Test user already exists", user: { id: existingUser.id, email: existingUser.email } });
    }
    
    // Create user
    const passwordHash = await bcrypt.hash(password, 10);
    
    const result = await c.env.DB.prepare(`
      INSERT INTO password_users (email, password_hash, name, is_active, created_at, updated_at)
      VALUES (?, ?, ?, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(email, passwordHash, name).run();
    
    if (result.success) {
      return c.json({ 
        message: "Test user created successfully",
        user: { id: result.meta.last_row_id, email, name },
        credentials: { email, password }
      });
    } else {
      return c.json({ error: "Failed to create test user" }, 500);
    }
  } catch (error) {
    console.error("Create test user error:", error);
    return c.json({ error: "Failed to create test user" }, 500);
  }
});

export default app;
