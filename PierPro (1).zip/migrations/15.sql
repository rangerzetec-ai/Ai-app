
-- Create tenants table first
CREATE TABLE tenants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  domain TEXT,
  subscription_plan TEXT DEFAULT 'basic',
  is_active BOOLEAN DEFAULT TRUE,
  settings TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add tenant_id to all existing tables
ALTER TABLE clients ADD COLUMN tenant_id INTEGER;
ALTER TABLE projects ADD COLUMN tenant_id INTEGER;
ALTER TABLE leads ADD COLUMN tenant_id INTEGER;
ALTER TABLE appointments ADD COLUMN tenant_id INTEGER;
ALTER TABLE sales_people ADD COLUMN tenant_id INTEGER;
ALTER TABLE appointment_photos ADD COLUMN tenant_id INTEGER;
ALTER TABLE project_financials ADD COLUMN tenant_id INTEGER;
ALTER TABLE expense_categories ADD COLUMN tenant_id INTEGER;
ALTER TABLE project_expenses ADD COLUMN tenant_id INTEGER;
ALTER TABLE project_revenues ADD COLUMN tenant_id INTEGER;
ALTER TABLE engineers ADD COLUMN tenant_id INTEGER;
ALTER TABLE notification_contacts ADD COLUMN tenant_id INTEGER;
ALTER TABLE project_workflows ADD COLUMN tenant_id INTEGER;

-- Create tenant_users table for user-tenant relationships
CREATE TABLE tenant_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  is_active BOOLEAN DEFAULT TRUE,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for tenant-aware queries
CREATE INDEX idx_clients_tenant_id ON clients(tenant_id);
CREATE INDEX idx_projects_tenant_id ON projects(tenant_id);
CREATE INDEX idx_leads_tenant_id ON leads(tenant_id);
CREATE INDEX idx_appointments_tenant_id ON appointments(tenant_id);
CREATE INDEX idx_sales_people_tenant_id ON sales_people(tenant_id);
CREATE INDEX idx_appointment_photos_tenant_id ON appointment_photos(tenant_id);
CREATE INDEX idx_project_expenses_tenant_id ON project_expenses(tenant_id);
CREATE INDEX idx_project_revenues_tenant_id ON project_revenues(tenant_id);
CREATE INDEX idx_tenant_users_tenant_user ON tenant_users(tenant_id, user_id);

-- Insert default tenant for existing data
INSERT INTO tenants (name, slug, subscription_plan) VALUES ('Default Organization', 'default', 'enterprise');

-- Update existing data to belong to default tenant
UPDATE clients SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE projects SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE leads SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE appointments SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE sales_people SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE appointment_photos SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE project_financials SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE expense_categories SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE project_expenses SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE project_revenues SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE engineers SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE notification_contacts SET tenant_id = 1 WHERE tenant_id IS NULL;
UPDATE project_workflows SET tenant_id = 1 WHERE tenant_id IS NULL;
