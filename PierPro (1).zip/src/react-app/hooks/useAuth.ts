import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { useAuth as useMochaAuth } from '@getmocha/users-service/react';
import type { UserWithRole } from '../../worker/auth';

interface AuthContextType {
  user: UserWithRole | null;
  isPending: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  redirectToLogin: () => Promise<void>;
  exchangeCodeForSessionToken: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserWithRole | null>(null);
  const [isPending, setIsPending] = useState(true);
  const mochaAuth = useMochaAuth();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/users/me', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          if (mochaAuth.user) {
            setUser(mochaAuth.user as UserWithRole);
          } else {
            setUser(null);
          }
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        if (mochaAuth.user) {
          setUser(mochaAuth.user as UserWithRole);
        } else {
          setUser(null);
        }
      } finally {
        setIsPending(false);
      }
    };

    if (mochaAuth.isPending) {
      return;
    }

    checkAuth();
  }, [mochaAuth.user, mochaAuth.isPending]);

  const login = async (email: string, password: string) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
      credentials: 'include'
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Login failed');
    }

    const userResponse = await fetch('/api/users/me', {
      credentials: 'include'
    });
    
    if (userResponse.ok) {
      const userData = await userResponse.json();
      setUser(userData);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/logout', {
        credentials: 'include'
      });
    } catch (error) {
      console.error('Logout error:', error);
    }

    try {
      await mochaAuth.logout();
    } catch (error) {
      console.error('Mocha logout error:', error);
    }

    setUser(null);
  };

  const redirectToLogin = async () => {
    return mochaAuth.redirectToLogin();
  };

  const exchangeCodeForSessionToken = async () => {
    await mochaAuth.exchangeCodeForSessionToken();
    const userResponse = await fetch('/api/users/me', {
      credentials: 'include'
    });
    
    if (userResponse.ok) {
      const userData = await userResponse.json();
      setUser(userData);
    }
  };

  const authValue: AuthContextType = {
    user,
    isPending: isPending || mochaAuth.isPending,
    login,
    logout,
    redirectToLogin,
    exchangeCodeForSessionToken
  };

  return React.createElement(
    AuthContext.Provider,
    { value: authValue },
    children
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
